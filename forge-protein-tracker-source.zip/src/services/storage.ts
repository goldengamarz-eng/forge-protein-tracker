import { FoodEntry, DailyGoals, DailyTotals, MealTotals, MealType } from '../types';

const STORAGE_KEY_ENTRIES = 'forge_protein_entries_v1';
const STORAGE_KEY_GOALS = 'forge_protein_goals_v1';

export const DEFAULT_GOALS: DailyGoals = {
  protein: 165,
  calories: 2350,
  carbs: 220,
  fat: 65,
  bodyWeightKg: 78,
  goalType: 'hypertrophy',
  updatedAt: new Date().toISOString()
};

// Formats Date object to YYYY-MM-DD in local time
export function formatDateKey(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getTodayKey(): string {
  return formatDateKey(new Date());
}

// Generate realistic starter data for today and yesterday so the app feels populated on first launch
function getInitialSeedEntries(): FoodEntry[] {
  const today = getTodayKey();
  const yesterdayDate = new Date();
  yesterdayDate.setDate(yesterdayDate.getDate() - 1);
  const yesterday = formatDateKey(yesterdayDate);

  return [
    // Today's breakfast
    {
      id: 'seed-1',
      date: today,
      mealType: 'breakfast',
      name: 'Egg White & Whole Egg Scramble with Sourdough',
      portionSize: '3 eggs + 100g whites + 1 slice',
      quantity: 1,
      unit: 'serving',
      protein: 28,
      calories: 340,
      carbs: 24,
      fat: 12,
      notes: 'Cooked with olive oil spray',
      createdAt: new Date().toISOString()
    },
    // Today's morning snack
    {
      id: 'seed-2',
      date: today,
      mealType: 'snack',
      name: 'Greek Yogurt (0%) with Blueberries & Honey',
      portionSize: '200g yogurt',
      quantity: 1,
      unit: 'serving',
      protein: 22,
      calories: 160,
      carbs: 18,
      fat: 0,
      notes: 'High casein post-workout snack',
      createdAt: new Date().toISOString()
    },
    // Today's lunch
    {
      id: 'seed-3',
      date: today,
      mealType: 'lunch',
      name: 'Grilled Herb Chicken Breast with Quinoa & Asparagus',
      portionSize: '220g chicken + 120g quinoa',
      quantity: 1,
      unit: 'serving',
      protein: 52,
      calories: 520,
      carbs: 45,
      fat: 10,
      scannedFromPhoto: true,
      notes: 'Estimated via Forge AI Plate Scanner',
      createdAt: new Date().toISOString()
    },
    // Yesterday's sample entries
    {
      id: 'seed-y1',
      date: yesterday,
      mealType: 'breakfast',
      name: 'Overnight Whey Oats with Chia Seeds',
      portionSize: '1 scoop whey + 60g oats',
      quantity: 1,
      unit: 'serving',
      protein: 36,
      calories: 420,
      carbs: 52,
      fat: 8,
      createdAt: yesterdayDate.toISOString()
    },
    {
      id: 'seed-y2',
      date: yesterday,
      mealType: 'lunch',
      name: 'Seared Salmon Fillet with Brown Rice & Avocado',
      portionSize: '180g salmon',
      quantity: 1,
      unit: 'serving',
      protein: 42,
      calories: 580,
      carbs: 40,
      fat: 22,
      createdAt: yesterdayDate.toISOString()
    },
    {
      id: 'seed-y3',
      date: yesterday,
      mealType: 'dinner',
      name: 'Lean Ground Turkey Bolognese with Protein Pasta',
      portionSize: '200g turkey 93/7',
      quantity: 1,
      unit: 'serving',
      protein: 54,
      calories: 610,
      carbs: 60,
      fat: 12,
      createdAt: yesterdayDate.toISOString()
    },
    {
      id: 'seed-y4',
      date: yesterday,
      mealType: 'snack',
      name: 'Whey Isolate Protein Shake',
      portionSize: '1 scoop (30g)',
      quantity: 1,
      unit: 'serving',
      protein: 26,
      calories: 125,
      carbs: 2,
      fat: 1,
      createdAt: yesterdayDate.toISOString()
    }
  ];
}

export function loadFoodEntries(): FoodEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_ENTRIES);
    if (!raw) {
      const initial = getInitialSeedEntries();
      saveFoodEntries(initial);
      return initial;
    }
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error loading food entries from localStorage:', err);
    return getInitialSeedEntries();
  }
}

export function saveFoodEntries(entries: FoodEntry[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_ENTRIES, JSON.stringify(entries));
  } catch (err) {
    console.error('Error saving food entries to localStorage:', err);
  }
}

export function loadDailyGoals(): DailyGoals {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_GOALS);
    if (!raw) {
      saveDailyGoals(DEFAULT_GOALS);
      return DEFAULT_GOALS;
    }
    return { ...DEFAULT_GOALS, ...JSON.parse(raw) };
  } catch (err) {
    console.error('Error loading daily goals from localStorage:', err);
    return DEFAULT_GOALS;
  }
}

export function saveDailyGoals(goals: DailyGoals): void {
  try {
    localStorage.setItem(STORAGE_KEY_GOALS, JSON.stringify(goals));
  } catch (err) {
    console.error('Error saving daily goals to localStorage:', err);
  }
}

export function getEntriesForDate(entries: FoodEntry[], dateKey: string): FoodEntry[] {
  return entries.filter(item => item.date === dateKey);
}

export function calculateDailyTotals(entries: FoodEntry[]): DailyTotals {
  return entries.reduce(
    (acc, curr) => ({
      protein: acc.protein + (Number(curr.protein) || 0) * (Number(curr.quantity) || 1),
      calories: acc.calories + (Number(curr.calories) || 0) * (Number(curr.quantity) || 1),
      carbs: acc.carbs + (Number(curr.carbs) || 0) * (Number(curr.quantity) || 1),
      fat: acc.fat + (Number(curr.fat) || 0) * (Number(curr.quantity) || 1),
      itemCount: acc.itemCount + 1
    }),
    { protein: 0, calories: 0, carbs: 0, fat: 0, itemCount: 0 }
  );
}

export function calculateMealTotals(entries: FoodEntry[], mealType: MealType): MealTotals {
  const mealEntries = entries.filter(e => e.mealType === mealType);
  const totals = mealEntries.reduce(
    (acc, curr) => ({
      protein: acc.protein + (Number(curr.protein) || 0) * (Number(curr.quantity) || 1),
      calories: acc.calories + (Number(curr.calories) || 0) * (Number(curr.quantity) || 1),
      carbs: acc.carbs + (Number(curr.carbs) || 0) * (Number(curr.quantity) || 1),
      fat: acc.fat + (Number(curr.fat) || 0) * (Number(curr.quantity) || 1),
    }),
    { protein: 0, calories: 0, carbs: 0, fat: 0 }
  );

  return {
    ...totals,
    entries: mealEntries
  };
}

export function getHistorySummaries(entries: FoodEntry[], daysCount: number = 7): Array<{
  date: string;
  dayLabel: string;
  totalProtein: number;
  totalCalories: number;
  totalCarbs: number;
  totalFat: number;
  entryCount: number;
}> {
  const result = [];
  const today = new Date();

  for (let i = daysCount - 1; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const key = formatDateKey(d);
    const dayEntries = entries.filter(e => e.date === key);
    const totals = calculateDailyTotals(dayEntries);
    
    const dayLabel = i === 0 
      ? 'Today' 
      : i === 1 
      ? 'Yest' 
      : d.toLocaleDateString('en-US', { weekday: 'short' });

    result.push({
      date: key,
      dayLabel,
      totalProtein: Math.round(totals.protein),
      totalCalories: Math.round(totals.calories),
      totalCarbs: Math.round(totals.carbs),
      totalFat: Math.round(totals.fat),
      entryCount: dayEntries.length
    });
  }

  return result;
}

// Preset high-protein staple foods for ultra-fast 1-tap logging
export interface QuickStaple {
  name: string;
  portion: string;
  protein: number;
  calories: number;
  carbs: number;
  fat: number;
  category: string;
}

export const HIGH_PROTEIN_STAPLES: QuickStaple[] = [
  { name: 'Chicken Breast (Cooked)', portion: '200g (7 oz)', protein: 62, calories: 330, carbs: 0, fat: 7, category: 'Poultry' },
  { name: 'Whey Protein Isolate', portion: '1 scoop (30g)', protein: 25, calories: 120, carbs: 2, fat: 1, category: 'Supplements' },
  { name: 'Egg Whites (Liquid/Cooked)', portion: '200g (~6 whites)', protein: 22, calories: 104, carbs: 1, fat: 0, category: 'Eggs' },
  { name: 'Whole Eggs (Large)', portion: '3 large eggs', protein: 18, calories: 215, carbs: 1, fat: 15, category: 'Eggs' },
  { name: '0% Plain Greek Yogurt', portion: '200g (7 oz)', protein: 21, calories: 120, carbs: 7, fat: 0, category: 'Dairy' },
  { name: 'Canned Tuna in Water', portion: '1 can (130g drained)', protein: 32, calories: 140, carbs: 0, fat: 1, category: 'Fish' },
  { name: 'Atlantic Salmon Fillet', portion: '180g (6.3 oz)', protein: 40, calories: 380, carbs: 0, fat: 23, category: 'Fish' },
  { name: '93% Lean Ground Beef', portion: '180g (6.3 oz cooked)', protein: 46, calories: 350, carbs: 0, fat: 17, category: 'Meat' },
  { name: 'Low-Fat Cottage Cheese', portion: '200g (1 cup)', protein: 26, calories: 160, carbs: 8, fat: 3, category: 'Dairy' },
  { name: 'Extra Firm Tofu', portion: '200g (7 oz)', protein: 20, calories: 170, carbs: 4, fat: 9, category: 'Plant-Based' },
  { name: 'Cooked Jasmine Rice', portion: '150g (1 cup)', protein: 4, calories: 195, carbs: 43, fat: 0, category: 'Carbs' },
  { name: 'Steamed Broccoli', portion: '150g (1.5 cups)', protein: 4, calories: 52, carbs: 10, fat: 1, category: 'Veggies' }
];
