/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  FoodEntry, 
  DailyGoals, 
  MealType, 
  AIPhotoAnalysisResult 
} from './types';
import { 
  loadFoodEntries, 
  saveFoodEntries, 
  loadDailyGoals, 
  saveDailyGoals, 
  getTodayKey, 
  getEntriesForDate, 
  calculateDailyTotals 
} from './services/storage';

import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { FoodDiary } from './components/FoodDiary';
import { ManualAddFoodModal } from './components/ManualAddFoodModal';
import { AIScannerModal } from './components/AIScannerModal';
import { AIReviewModal } from './components/AIReviewModal';
import { GoalsModal } from './components/GoalsModal';
import { WeeklyHistoryModal } from './components/WeeklyHistoryModal';
import { AndroidExportModal } from './components/AndroidExportModal';
import { ProteinChatModal } from './ProteinChatModal';

import { Camera, Plus, Target, Calendar, Smartphone, UtensilsCrossed } from 'lucide-react';

export default function App() {
  const [entries, setEntries] = useState<FoodEntry[]>(() => loadFoodEntries());
  const [goals, setGoals] = useState<DailyGoals>(() => loadDailyGoals());
  const [currentDateKey, setCurrentDateKey] = useState<string>(() => getTodayKey());

  // Modal visibility states
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isManualAddOpen, setIsManualAddOpen] = useState(false);
  const [isReviewOpen, setIsReviewOpen] = useState(false);
  const [isGoalsOpen, setIsGoalsOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isApkGuideOpen, setIsApkGuideOpen] = useState(false);
const [isChatOpen, setIsChatOpen] = useState(false);

  // Modal context states
  const [manualAddMeal, setManualAddMeal] = useState<MealType>('lunch');
  const [editingEntry, setEditingEntry] = useState<FoodEntry | null>(null);
  const [currentAnalysis, setCurrentAnalysis] = useState<AIPhotoAnalysisResult | null>(null);
  const [currentPhotoDataUrl, setCurrentPhotoDataUrl] = useState<string>('');

  // Persist entries whenever modified
  useEffect(() => {
    saveFoodEntries(entries);
  }, [entries]);

  // Persist goals whenever modified
  useEffect(() => {
    saveDailyGoals(goals);
  }, [goals]);

  // Filter entries for the selected day
  const dayEntries = useMemo(() => {
    return getEntriesForDate(entries, currentDateKey);
  }, [entries, currentDateKey]);

  // Compute daily totals
  const dailyTotals = useMemo(() => {
    return calculateDailyTotals(dayEntries);
  }, [dayEntries]);

  const proteinGoalMet = dailyTotals.protein >= goals.protein;

  // Add or update handlers
  const handleSaveManualEntry = (entryData: Omit<FoodEntry, 'id' | 'createdAt'>) => {
    const newEntry: FoodEntry = {
      ...entryData,
      id: `entry-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      createdAt: new Date().toISOString()
    };
    setEntries(prev => [newEntry, ...prev]);
  };

  const handleUpdateEntry = (entryId: string, updatedFields: Partial<FoodEntry>) => {
    setEntries(prev => prev.map(item => item.id === entryId ? { ...item, ...updatedFields } : item));
    setEditingEntry(null);
  };

  const handleDeleteEntry = (entryId: string) => {
    setEntries(prev => prev.filter(item => item.id !== entryId));
  };

  const handleEditEntry = (entry: FoodEntry) => {
    setEditingEntry(entry);
    setManualAddMeal(entry.mealType);
    setIsManualAddOpen(true);
  };

  const handleOpenManualAddWithMeal = (meal: MealType) => {
    setEditingEntry(null);
    setManualAddMeal(meal);
    setIsManualAddOpen(true);
  };

  // AI Vision analysis flow
  const handleAnalysisSuccess = (analysis: AIPhotoAnalysisResult, photoDataUrl: string) => {
    setCurrentAnalysis(analysis);
    setCurrentPhotoDataUrl(photoDataUrl);
    setIsReviewOpen(true);
  };

  const handleConfirmReviewAndLog = (newEntries: Array<Omit<FoodEntry, 'id' | 'createdAt'>>) => {
    const created: FoodEntry[] = newEntries.map(item => ({
      ...item,
      id: `ai-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      createdAt: new Date().toISOString()
    }));
    setEntries(prev => [...created, ...prev]);
  };

  const handleSaveGoals = (updatedGoals: DailyGoals) => {
    setGoals(updatedGoals);
  };

  const handleImportBackup = (importedEntries: FoodEntry[], importedGoals: DailyGoals) => {
    setEntries(importedEntries);
    setGoals(importedGoals);
  };

  return (
    <div className="min-h-screen bg-[#08090d] text-gray-100 flex flex-col font-sans pb-24 selection:bg-[#a3e635] selection:text-black">
      {/* Sticky Header with Date Navigator */}
      <Header
        currentDateKey={currentDateKey}
        onDateChange={setCurrentDateKey}
        onOpenScanner={() => setIsScannerOpen(true)}
        onOpenManualAdd={() => {
          setEditingEntry(null);
          setIsManualAddOpen(true);
        }}
        onOpenGoals={() => setIsGoalsOpen(true)}
        onOpenHistory={() => setIsHistoryOpen(true)}
        onOpenApkGuide={() => setIsApkGuideOpen(true)}
        proteinGoalMet={proteinGoalMet}
      />

      {/* Main Content Area: Responsive Mobile Container */}
      <main className="flex-1 max-w-3xl w-full mx-auto px-3.5 sm:px-6 py-4 space-y-4">
        {/* Fitness Macro Dashboard */}
        <Dashboard
          totals={dailyTotals}
          goals={goals}
          onOpenGoals={() => setIsGoalsOpen(true)}
        />

        {/* Food Diary */}
        <FoodDiary
          entries={dayEntries}
          onOpenManualAddWithMeal={handleOpenManualAddWithMeal}
          onEditEntry={handleEditEntry}
          onDeleteEntry={handleDeleteEntry}
        />
      </main>

      {/* Floating Mobile Bottom Navigation Bar (optimized for Android thumb zones) */}
      <nav className="fixed bottom-0 inset-x-0 z-40 bg-[#090b10]/95 backdrop-blur-lg border-t border-[#1c2333] py-2 px-4">
        <div className="max-w-md mx-auto flex items-center justify-around">
          {/* Diary view button */}
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="flex flex-col items-center gap-1 text-gray-300 hover:text-white transition-colors"
          >
            <UtensilsCrossed className="w-5 h-5 text-gray-400" />
            <span className="text-[10px] font-semibold">Diary</span>
          </button>

          {/* Quick Add */}
          <button
            onClick={() => {
              setEditingEntry(null);
              setIsManualAddOpen(true);
            }}
            className="flex flex-col items-center gap-1 text-gray-300 hover:text-white transition-colors"
          >
            <div className="w-8 h-8 rounded-full bg-[#1b2233] border border-[#2b364d] flex items-center justify-center text-[#a3e635]">
              <Plus className="w-4 h-4 stroke-[2.5]" />
            </div>
            <span className="text-[10px] font-semibold">Log Food</span>
          </button>

          {/* Central Glowing AI Scan Button */}
          <button
            onClick={() => setIsScannerOpen(true)}
            className="relative -top-3 flex flex-col items-center group"
          >
            <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-[#84cc16] to-[#bef264] text-black flex items-center justify-center shadow-lg shadow-[#a3e635]/30 group-active:scale-95 transition-all">
              <Camera className="w-6 h-6 stroke-[2.5]" />
            </div>
            <span className="text-[11px] font-black text-[#a3e635] tracking-tight mt-0.5">
              AI SCAN
            </span>
          </button>

          {/* Goals */}
          <button
            onClick={() => setIsGoalsOpen(true)}
            className="flex flex-col items-center gap-1 text-gray-300 hover:text-white transition-colors"
          >
            <Target className="w-5 h-5 text-sky-400" />
            <span className="text-[10px] font-semibold">Targets</span>
          </button>

          {/* 7-Day History */}
          <button
            onClick={() => setIsHistoryOpen(true)}
            className="flex flex-col items-center gap-1 text-gray-300 hover:text-white transition-colors"
          >
            <Calendar className="w-5 h-5 text-[#a3e635]" />
            <span className="text-[10px] font-semibold">History</span>
          </button>
        </div>
      </nav>

      {/* Modals */}
      <ManualAddFoodModal
        isOpen={isManualAddOpen}
        onClose={() => {
          setIsManualAddOpen(false);
          setEditingEntry(null);
        }}
        onSave={handleSaveManualEntry}
        onUpdate={handleUpdateEntry}
        dateKey={currentDateKey}
        defaultMeal={manualAddMeal}
        editingEntry={editingEntry}
      />

      <AIScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onAnalysisSuccess={handleAnalysisSuccess}
        onOpenApkGuide={() => {
          setIsScannerOpen(false);
          setIsApkGuideOpen(true);
        }}
      />

      <AIReviewModal
        isOpen={isReviewOpen}
        onClose={() => setIsReviewOpen(false)}
        analysis={currentAnalysis}
        photoDataUrl={currentPhotoDataUrl}
        dateKey={currentDateKey}
        onConfirmAndLog={handleConfirmReviewAndLog}
      />

      <GoalsModal
        isOpen={isGoalsOpen}
        onClose={() => setIsGoalsOpen(false)}
        goals={goals}
        onSaveGoals={handleSaveGoals}
      />

      <WeeklyHistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        entries={entries}
        goals={goals}
        onSelectDate={setCurrentDateKey}
      />

      <AndroidExportModal
        isOpen={isApkGuideOpen}
        onClose={() => setIsApkGuideOpen(false)}
        entries={entries}
        goals={goals}
        onImportData={handleImportBackup}
      />
            {/* Floating Chat Button */}
      <button
        onClick={() => setIsChatOpen(true)}
        style={{
          position: 'fixed',
          bottom: '80px',
          right: '18px',
          width: '52px',
          height: '52px',
          borderRadius: '50%',
          backgroundColor: '#39e75f',
          color: '#000',
          border: 'none',
          boxShadow: '0 4px 14px rgba(57, 231, 95, 0.4)',
          fontSize: '1.4rem',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          cursor: 'pointer',
          zIndex: 999
        }}
      >
        💬
      </button>

      <ProteinChatModal
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        serverUrl="https://forge-protein-tracker.onrender.com"
      />
      
    </div>
  );
}
