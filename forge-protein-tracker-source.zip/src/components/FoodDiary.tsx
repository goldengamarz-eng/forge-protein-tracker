import React from 'react';
import { FoodEntry, MealType } from '../types';
import { calculateMealTotals } from '../services/storage';
import { Plus, Trash2, Edit3, Camera, Coffee, Sun, Moon, Apple } from 'lucide-react';

interface FoodDiaryProps {
  entries: FoodEntry[];
  onOpenManualAddWithMeal: (meal: MealType) => void;
  onEditEntry: (entry: FoodEntry) => void;
  onDeleteEntry: (entryId: string) => void;
}

const MEALS_CONFIG: Array<{
  type: MealType;
  title: string;
  icon: React.ReactNode;
  hint: string;
}> = [
  {
    type: 'breakfast',
    title: 'Breakfast',
    icon: <Coffee className="w-4 h-4 text-amber-400" />,
    hint: 'Eggs, Greek yogurt, oats, protein smoothie...'
  },
  {
    type: 'lunch',
    title: 'Lunch',
    icon: <Sun className="w-4 h-4 text-yellow-400" />,
    hint: 'Chicken breast, rice, greens, salmon bowl...'
  },
  {
    type: 'dinner',
    title: 'Dinner',
    icon: <Moon className="w-4 h-4 text-indigo-400" />,
    hint: 'Lean beef, fish, sweet potato, stir-fry...'
  },
  {
    type: 'snack',
    title: 'Snacks & Supplements',
    icon: <Apple className="w-4 h-4 text-[#a3e635]" />,
    hint: 'Whey shake, cottage cheese, protein bar, fruit...'
  }
];

export const FoodDiary: React.FC<FoodDiaryProps> = ({
  entries,
  onOpenManualAddWithMeal,
  onEditEntry,
  onDeleteEntry
}) => {
  return (
    <section className="space-y-3">
      <div className="flex items-center justify-between px-1">
        <h3 className="text-xs uppercase font-extrabold tracking-wider text-gray-400">
          Meal Diary
        </h3>
        <span className="text-[11px] text-gray-500">
          {entries.length} {entries.length === 1 ? 'item' : 'items'} today
        </span>
      </div>

      <div className="space-y-3">
        {MEALS_CONFIG.map(({ type, title, icon, hint }) => {
          const mealData = calculateMealTotals(entries, type);
          const hasEntries = mealData.entries.length > 0;

          return (
            <div
              key={type}
              className="rounded-2xl bg-[#11141e] border border-[#202738] overflow-hidden transition-all duration-200"
            >
              {/* Meal Header */}
              <div className="p-3.5 flex items-center justify-between border-b border-[#1b2230] bg-[#141824]/60">
                <div className="flex items-center gap-2.5">
                  <span className="p-1.5 rounded-lg bg-[#1b2233] border border-[#273247]">
                    {icon}
                  </span>
                  <div>
                    <h4 className="text-sm font-bold text-white leading-tight">
                      {title}
                    </h4>
                    <span className="text-[11px] font-mono text-gray-400">
                      {Math.round(mealData.calories)} kcal
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {/* Meal Protein Tag */}
                  <div className="px-2 py-0.5 rounded-md bg-[#a3e635]/15 border border-[#a3e635]/30 text-[11px] font-mono font-bold text-[#a3e635]">
                    {Math.round(mealData.protein)}g P
                  </div>

                  {/* Add button */}
                  <button
                    onClick={() => onOpenManualAddWithMeal(type)}
                    className="p-1.5 rounded-lg bg-[#1b2233] hover:bg-[#252f44] text-gray-300 hover:text-white border border-[#273247] transition-colors"
                    title={`Add to ${title}`}
                  >
                    <Plus className="w-3.5 h-3.5 text-[#a3e635]" />
                  </button>
                </div>
              </div>

              {/* Meal Entry Items */}
              {hasEntries ? (
                <div className="divide-y divide-[#181f2c]">
                  {mealData.entries.map((item) => {
                    const totalProtein = Math.round(item.protein * item.quantity);
                    const totalCals = Math.round(item.calories * item.quantity);
                    const totalCarbs = Math.round(item.carbs * item.quantity);
                    const totalFat = Math.round(item.fat * item.quantity);

                    return (
                      <div
                        key={item.id}
                        className="p-3 flex items-center justify-between hover:bg-[#141926]/50 transition-colors group"
                      >
                        <div className="flex-1 min-w-0 pr-3">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-sm text-gray-100 truncate">
                              {item.name}
                            </span>
                            {item.scannedFromPhoto && (
                              <span
                                title="Scanned with AI Diet Vision"
                                className="inline-flex items-center gap-0.5 px-1.5 py-0.2 rounded text-[9px] uppercase font-bold tracking-tight bg-[#a3e635]/15 text-[#a3e635] border border-[#a3e635]/30"
                              >
                                <Camera className="w-2.5 h-2.5" /> AI
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-2 text-xs text-gray-400 mt-0.5">
                            {item.portionSize && (
                              <span className="truncate max-w-[130px] text-gray-400">
                                {item.quantity > 1 ? `${item.quantity}x ` : ''}{item.portionSize}
                              </span>
                            )}
                            <span className="text-gray-600">•</span>
                            <span className="font-mono text-gray-300 font-medium">{totalCals} kcal</span>
                          </div>

                          {/* Secondary macro tags */}
                          <div className="flex items-center gap-2 mt-1 text-[11px] font-mono">
                            <span className="text-[#a3e635] font-bold">
                              {totalProtein}g P
                            </span>
                            <span className="text-sky-400">
                              {totalCarbs}g C
                            </span>
                            <span className="text-orange-400">
                              {totalFat}g F
                            </span>
                            {item.notes && (
                              <span className="text-[10px] text-gray-500 truncate max-w-[140px] italic">
                                ({item.notes})
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-1 opacity-90 sm:opacity-75 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => onEditEntry(item)}
                            className="p-1.5 rounded-lg hover:bg-[#1c2333] text-gray-400 hover:text-white transition-colors"
                            title="Edit Food Entry"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDeleteEntry(item.id)}
                            className="p-1.5 rounded-lg hover:bg-rose-950/40 text-gray-500 hover:text-rose-400 transition-colors"
                            title="Delete Food Entry"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                /* Empty state for meal */
                <div className="p-3 text-center">
                  <p className="text-xs text-gray-500 italic">
                    {hint}
                  </p>
                  <button
                    onClick={() => onOpenManualAddWithMeal(type)}
                    className="mt-1.5 inline-flex items-center gap-1 text-[11px] font-semibold text-[#a3e635] hover:text-[#bef264] transition-colors"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Log {title}</span>
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
};
