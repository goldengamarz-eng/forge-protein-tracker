import React, { useState } from 'react';
import { X, Smartphone, Key, Download, Upload, ShieldCheck, Terminal, Copy, Check } from 'lucide-react';
import { FoodEntry, DailyGoals } from '../types';

interface AndroidExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  entries: FoodEntry[];
  goals: DailyGoals;
  onImportData: (entries: FoodEntry[], goals: DailyGoals) => void;
}

export const AndroidExportModal: React.FC<AndroidExportModalProps> = ({
  isOpen,
  onClose,
  entries,
  goals,
  onImportData
}) => {
  const [activeTab, setActiveTab] = useState<'apk' | 'ai' | 'backup'>('apk');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);
  const [zipDownloadStatus, setZipDownloadStatus] = useState<string | null>(null);
  const [zipDownloadError, setZipDownloadError] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleDownloadZip = async () => {
    setIsDownloadingZip(true);
    setZipDownloadError(null);
    setZipDownloadStatus('Reading & compressing project files on server...');

    try {
      const response = await fetch('/api/export-project-zip', {
        headers: {
          'Accept': 'application/zip, application/octet-stream'
        }
      });

      if (!response.ok) {
        throw new Error(`Server returned HTTP ${response.status}: ${response.statusText}`);
      }

      const contentType = response.headers.get('content-type') || '';
      if (contentType.includes('text/html')) {
        throw new Error('Server returned HTML instead of a ZIP binary. Please use the direct browser link below.');
      }

      const arrayBuffer = await response.arrayBuffer();
      const bytes = new Uint8Array(arrayBuffer);

      // Validate ZIP magic numbers: 0x50, 0x4B, 0x03, 0x04 ('PK\x03\x04')
      if (bytes[0] !== 0x50 || bytes[1] !== 0x4b || bytes[2] !== 0x03 || bytes[3] !== 0x04) {
        throw new Error('Downloaded file failed ZIP binary verification.');
      }

      // Create genuine binary ZIP blob
      const zipBlob = new Blob([arrayBuffer], { type: 'application/zip' });
      const blobUrl = URL.createObjectURL(zipBlob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = 'forge-protein-tracker-source.zip';
      link.setAttribute('download', 'forge-protein-tracker-source.zip');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(blobUrl), 3000);

      setZipDownloadStatus('✓ Real ZIP file downloaded! Saved as forge-protein-tracker-source.zip (~47 KB). Check your Android "Downloads" folder.');
    } catch (err: any) {
      console.error('ZIP download error:', err);
      setZipDownloadError(err?.message || 'Failed to download ZIP file.');
      setZipDownloadStatus(null);
    } finally {
      setIsDownloadingZip(false);
    }
  };

  const handleExportBackup = () => {
    const backupData = {
      app: 'Forge Protein Tracker',
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      goals,
      entries
    };

    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `forge-protein-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.entries && Array.isArray(parsed.entries)) {
          onImportData(parsed.entries, parsed.goals || goals);
          alert(`Successfully imported ${parsed.entries.length} food entries!`);
          onClose();
        } else {
          alert('Invalid backup file format.');
        }
      } catch (err) {
        alert('Could not parse JSON backup file.');
      }
    };
    reader.readAsText(file);
  };

  const capacitorCommands = `npm install @capacitor/core @capacitor/android
npx cap init "Forge" "com.forge.proteintracker" --web-dir dist
npm run build
npx cap add android
npx cap copy android
npx cap open android`;

  const bubblewrapCommands = `npm install -g @bubblewrap/cli
bubblewrap init --manifest="${window.location.origin}/manifest.json"
bubblewrap build`;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full sm:max-w-xl bg-[#0e111a] border border-[#232b3d] rounded-t-3xl sm:rounded-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-[#1b2233] flex items-center justify-between bg-[#131724]">
          <div className="flex items-center gap-2">
            <span className="flex items-center justify-center w-8 h-8 rounded-lg bg-[#a3e635]/20 text-[#a3e635]">
              <Smartphone className="w-4 h-4" />
            </span>
            <div>
              <h3 className="font-bold text-base text-white">Android & AI Configuration</h3>
              <p className="text-xs text-gray-400">Export APK, configure Gemini Vision, and backup data</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-[#202738] text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex border-b border-[#1c2333] bg-[#121624] px-4 pt-2 gap-2">
          <button
            onClick={() => setActiveTab('apk')}
            className={`pb-2.5 px-3 text-xs font-bold transition-all relative ${
              activeTab === 'apk'
                ? 'text-[#a3e635] border-b-2 border-[#a3e635]'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Build Android APK
          </button>
          <button
            onClick={() => setActiveTab('ai')}
            className={`pb-2.5 px-3 text-xs font-bold transition-all relative ${
              activeTab === 'ai'
                ? 'text-[#a3e635] border-b-2 border-[#a3e635]'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            AI Photo Setup
          </button>
          <button
            onClick={() => setActiveTab('backup')}
            className={`pb-2.5 px-3 text-xs font-bold transition-all relative ${
              activeTab === 'backup'
                ? 'text-[#a3e635] border-b-2 border-[#a3e635]'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Data Backup & Restore
          </button>
        </div>

        {/* Tab Contents */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs leading-relaxed">
          {activeTab === 'apk' && (
            <div className="space-y-4">
              {/* Highlight for phone-only users */}
              <div className="p-3 bg-[#a3e635]/10 border border-[#a3e635]/30 rounded-xl space-y-2.5">
                <div className="flex items-start gap-2.5">
                  <span className="text-base leading-none">📱</span>
                  <div>
                    <h4 className="font-bold text-[#a3e635] text-xs">Using Only An Android Phone?</h4>
                    <p className="text-gray-300 text-[11px] mt-0.5">
                      You do <span className="underline font-semibold">not</span> need a computer. Tap below to download the genuine verified ZIP archive directly into your phone's Downloads folder.
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  <button
                    type="button"
                    disabled={isDownloadingZip}
                    onClick={handleDownloadZip}
                    className="w-full py-2.5 px-3 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-black font-extrabold text-xs flex items-center justify-center gap-2 shadow-md shadow-[#a3e635]/20 active:scale-95 transition-all disabled:opacity-60 text-center"
                  >
                    <Download className="w-4 h-4 stroke-[2.5]" />
                    <span>{isDownloadingZip ? 'Downloading Real ZIP...' : 'Download Project ZIP (Verified Binary)'}</span>
                  </button>

                  {/* Fallback buttons if browser sandbox prevents blob download */}
                  <div className="flex items-center gap-1.5 pt-1">
                    <a
                      href="/api/export-project-zip"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 py-1.5 px-2 rounded-lg bg-[#181f2f] hover:bg-[#232c40] text-gray-300 hover:text-white border border-[#2b364d] text-[10px] font-semibold text-center"
                    >
                      Open Direct Link in New Tab
                    </a>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(`${window.location.origin}/api/export-project-zip`, 99)}
                      className="py-1.5 px-2.5 rounded-lg bg-[#181f2f] hover:bg-[#232c40] text-gray-300 hover:text-white border border-[#2b364d] text-[10px] font-semibold flex items-center gap-1"
                    >
                      {copiedIndex === 99 ? <Check className="w-3 h-3 text-[#a3e635]" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedIndex === 99 ? 'Copied' : 'Copy URL'}</span>
                    </button>
                  </div>

                  {zipDownloadStatus && (
                    <div className="p-2 rounded-lg bg-emerald-950/40 border border-emerald-700/60 text-emerald-300 text-[11px] font-medium animate-in fade-in">
                      {zipDownloadStatus}
                    </div>
                  )}

                  {zipDownloadError && (
                    <div className="p-2 rounded-lg bg-rose-950/40 border border-rose-700/60 text-rose-300 text-[11px] font-medium space-y-1 animate-in fade-in">
                      <p><strong>Download Notice:</strong> {zipDownloadError}</p>
                      <p className="text-[10px] text-gray-300">
                        Tip: Tap "Open Direct Link in New Tab" or paste the copied URL directly into your Android Chrome address bar.
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Method 1: Instant WebAPK Install */}
              <div className="p-3.5 rounded-xl bg-[#141824] border border-[#232b3d] space-y-2">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <span className="w-5 h-5 rounded-full bg-[#a3e635] text-black text-xs flex items-center justify-center font-black">1</span>
                  <span>Instant Phone WebAPK (Google Play Services)</span>
                </div>
                <p className="text-gray-300">
                  Android Chrome integrates directly with Google Play Services to generate and install a real signed system APK on your device:
                </p>
                <ol className="list-decimal list-inside space-y-1 text-gray-400 pl-1">
                  <li>Open Forge in <strong className="text-white">Google Chrome</strong> on your phone.</li>
                  <li>Tap the <strong>⋮</strong> Chrome menu icon in the upper-right corner.</li>
                  <li>Tap <strong className="text-[#a3e635]">"Install App"</strong> (or "Add to Home screen").</li>
                  <li>Android Play Services will build and install the APK package (<code className="text-gray-300 font-mono">org.chromium.webapk</code>) directly to your app drawer with native system permissions and an offline service worker.</li>
                </ol>
              </div>

              {/* Method 2: GitHub Actions Cloud APK */}
              <div className="p-3.5 rounded-xl bg-[#141824] border border-[#232b3d] space-y-2.5">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <span className="w-5 h-5 rounded-full bg-[#38bdf8] text-black text-xs flex items-center justify-center font-black">2</span>
                  <span>Automated Cloud APK Build (Zero-PC Required)</span>
                </div>
                <p className="text-gray-300">
                  This repository includes a ready-to-run GitHub Actions CI workflow in <code className="text-[#a3e635] font-mono">.github/workflows/android-apk.yml</code>:
                </p>
                <ol className="list-decimal list-inside space-y-1 text-gray-400 pl-1">
                  <li>Push or fork this repository to your GitHub account (accessible via phone browser).</li>
                  <li>In GitHub, tap the <strong className="text-white">Actions</strong> tab &gt; <strong className="text-white">Build Android APK</strong> &gt; <strong className="text-[#38bdf8]">Run workflow</strong>.</li>
                  <li>GitHub's cloud runner builds the Android project with Java 17 and Gradle in ~2 minutes.</li>
                  <li>Under <strong className="text-white">Artifacts</strong>, tap <strong className="text-[#a3e635]">forge-protein-tracker-debug-apk</strong> to download the raw <code className="text-white font-mono">app-debug.apk</code> directly into your phone's Downloads folder!</li>
                </ol>
              </div>

              {/* Method 3: Termux on Android Phone */}
              <div className="p-3.5 rounded-xl bg-[#141824] border border-[#232b3d] space-y-2">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <span className="w-5 h-5 rounded-full bg-[#fb923c] text-black text-xs flex items-center justify-center font-black">3</span>
                  <span>Local Compilation inside Termux (Advanced Phone Users)</span>
                </div>
                <p className="text-gray-300">
                  If you run the Termux terminal emulator directly on your Android phone, you can compile locally:
                </p>
                <div className="bg-[#090b10] p-2.5 rounded-lg border border-[#232a38] font-mono text-[11px] text-[#a3e635] overflow-x-auto whitespace-pre">
pkg install openjdk-17 nodejs-lts git
npm install && npm run build
npx cap add android && cd android && ./gradlew assembleDebug</div>
              </div>

              {/* Method 4: Capacitor Developer Workstation */}
              <div className="p-3.5 rounded-xl bg-[#141824] border border-[#232b3d] space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-white font-bold text-sm">
                    <span className="w-5 h-5 rounded-full bg-purple-400 text-black text-xs flex items-center justify-center font-black">4</span>
                    <span>Android Studio / Capacitor CLI (If PC is available)</span>
                  </div>
                  <button
                    onClick={() => copyToClipboard(capacitorCommands, 1)}
                    className="flex items-center gap-1 text-[11px] text-[#a3e635] hover:text-[#bef264]"
                  >
                    {copiedIndex === 1 ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedIndex === 1 ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
                <div className="bg-[#090b10] p-2.5 rounded-lg border border-[#232a38] font-mono text-[11px] text-[#a3e635] overflow-x-auto whitespace-pre">
                  {capacitorCommands}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'ai' && (
            <div className="space-y-3.5">
              <div className="p-3.5 rounded-xl bg-[#141824] border border-[#232b3d] space-y-2">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <ShieldCheck className="w-4 h-4 text-[#a3e635]" />
                  <span>Secure Server-Side AI Architecture</span>
                </div>
                <p className="text-gray-300">
                  Forge implements strict server-side AI processing. Your Gemini API key is <strong className="text-white">never bundled or exposed in client-side browser code</strong>. All vision requests are proxied securely through the <code className="text-[#a3e635] font-mono">/api/scan-food</code> backend endpoint.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-[#141824] border border-[#232b3d] space-y-2.5">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <Key className="w-4 h-4 text-amber-400" />
                  <span>How to Add Your Gemini API Key</span>
                </div>
                <ol className="list-decimal list-inside space-y-2 text-gray-300 pl-1">
                  <li>
                    In <strong>Google AI Studio</strong>, click on the <strong className="text-white">Settings</strong> icon (or Secrets panel).
                  </li>
                  <li>
                    Add a secret named <code className="text-[#a3e635] font-mono bg-black/40 px-1.5 py-0.5 rounded">GEMINI_API_KEY</code> with your Google AI Studio API key.
                  </li>
                  <li>
                    If running locally or self-hosting, place it in your root <code className="text-[#a3e635] font-mono bg-black/40 px-1.5 py-0.5 rounded">.env</code> file:
                    <div className="bg-black/60 p-2 rounded border border-[#252c3c] font-mono text-[11px] text-gray-300 mt-1">
                      GEMINI_API_KEY="AIzaSy..."
                    </div>
                  </li>
                  <li>
                    The backend automatically detects the key without code changes and routes image scans through <strong className="text-[#a3e635]">gemini-3.8-flash</strong>.
                  </li>
                </ol>
              </div>

              <div className="p-3 rounded-xl bg-[#131724] border border-[#202738] text-gray-400 space-y-1">
                <div className="font-bold text-gray-200">Zero Fake AI Guarantee:</div>
                <p>
                  In accordance with high medical and nutrition integrity standards, Forge will never fabricate artificial AI responses if no key is configured. If unconfigured, the app will cleanly report the configuration requirement and allow manual logging or sample review.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'backup' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-[#141824] border border-[#232b3d] space-y-2">
                <h4 className="font-bold text-white text-sm">Local Storage & Portability</h4>
                <p className="text-gray-300">
                  All your food entries, macro goals, and meal history are saved persistently in your browser's private local database. You can export a JSON backup anytime to transfer to another device or restore in case you clear browser cookies.
                </p>
                <div className="text-[11px] text-[#a3e635] font-mono">
                  Currently stored: {entries.length} food entries across your diary.
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={handleExportBackup}
                  className="p-3 rounded-xl bg-[#1a2131] hover:bg-[#232d43] border border-[#2b374f] text-white flex flex-col items-center justify-center gap-1.5 transition-colors group"
                >
                  <Download className="w-5 h-5 text-[#a3e635] group-hover:scale-110 transition-transform" />
                  <span className="font-bold text-xs">Download JSON Backup</span>
                  <span className="text-[10px] text-gray-400">Save entries & goals</span>
                </button>

                <label className="p-3 rounded-xl bg-[#1a2131] hover:bg-[#232d43] border border-[#2b374f] text-white flex flex-col items-center justify-center gap-1.5 transition-colors group cursor-pointer">
                  <Upload className="w-5 h-5 text-sky-400 group-hover:scale-110 transition-transform" />
                  <span className="font-bold text-xs">Restore from Backup</span>
                  <span className="text-[10px] text-gray-400">Upload JSON file</span>
                  <input
                    type="file"
                    accept=".json"
                    className="hidden"
                    onChange={handleImportBackup}
                  />
                </label>
              </div>

              {/* Full Project Code ZIP */}
              <div className="p-3.5 rounded-xl bg-[#141824] border border-[#232b3d] space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <h5 className="font-bold text-white text-xs">Full Application Source Code</h5>
                    <p className="text-[11px] text-gray-400 mt-0.5">
                      Export all frontend files, server code, manifests, and Android CI configurations.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  disabled={isDownloadingZip}
                  onClick={handleDownloadZip}
                  className="w-full py-2.5 px-3 rounded-xl bg-[#1b2233] hover:bg-[#252f44] text-[#a3e635] font-bold text-xs border border-[#273247] flex items-center justify-center gap-2 transition-colors text-center disabled:opacity-50"
                >
                  <Download className="w-4 h-4" />
                  <span>{isDownloadingZip ? 'Downloading ZIP Archive...' : 'Download Complete Project (.ZIP)'}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
