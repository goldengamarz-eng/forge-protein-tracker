import React, { useState, useRef } from 'react';
import { Camera, Upload, AlertCircle, Loader2, Sparkles, X, Key, Info } from 'lucide-react';
import { AIPhotoAnalysisResult } from '../types';

interface AIScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAnalysisSuccess: (analysis: AIPhotoAnalysisResult, photoDataUrl: string) => void;
  onOpenApkGuide: () => void;
}

export const AIScannerModal: React.FC<AIScannerModalProps> = ({
  isOpen,
  onClose,
  onAnalysisSuccess,
  onOpenApkGuide
}) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [promptHint, setPromptHint] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [scanStepMessage, setScanStepMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isKeyMissing, setIsKeyMissing] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMessage('Please select a valid image file (JPEG, PNG, WEBP, or HEIC).');
      return;
    }

    setErrorMessage(null);
    setIsKeyMissing(false);

    const reader = new FileReader();
    reader.onload = () => {
      setSelectedImage(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleStartScan = async () => {
    if (!selectedImage) return;

    setIsScanning(true);
    setErrorMessage(null);
    setIsKeyMissing(false);
    setScanStepMessage('Sending photo to secure server...');

    const stepTimer1 = setTimeout(() => {
      setScanStepMessage('Gemini 3.8 Flash analyzing plate contents...');
    }, 1200);

    const stepTimer2 = setTimeout(() => {
      setScanStepMessage('Estimating portion weights & calculating protein...');
    }, 2800);

    try {
      const response = await fetch('/api/scan-food', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          imageBase64: selectedImage,
          userPrompt: promptHint.trim() || undefined
        })
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        if (result.error === 'AI_KEY_NOT_CONFIGURED') {
          setIsKeyMissing(true);
          throw new Error('GEMINI_API_KEY is not configured on the server.');
        }
        throw new Error(result.message || 'Analysis failed. Please check the meal image.');
      }

      // Success: pass to review screen
      onAnalysisSuccess(result.data, selectedImage);
      onClose();

    } catch (err: any) {
      console.error('Scan error:', err);
      setErrorMessage(err?.message || 'Failed to scan meal. Check your connection or try again.');
    } finally {
      clearTimeout(stepTimer1);
      clearTimeout(stepTimer2);
      setIsScanning(false);
    }
  };

  // Demo Plate for previewing the editable review flow without faking live AI
  const handleLoadDemoPlate = () => {
    const sampleAnalysis: AIPhotoAnalysisResult = {
      dishTitle: 'Pan-Seared Sirloin Steak with Sweet Potato & Asparagus (Demo)',
      summary: 'High-protein whole food meal with rich leucine and complex slow-digesting carbohydrates.',
      confidence: 'high',
      totalProtein: 54,
      totalCalories: 640,
      totalCarbs: 48,
      totalFat: 24,
      dietaryTags: ['High Protein', 'Whole Foods', 'Post-Workout Fuel'],
      estimationDisclaimer: 'AI Nutrition Estimate: Visual approximation based on standard culinary densities.',
      items: [
        {
          name: 'Grass-Fed Sirloin Steak',
          estimatedPortion: '220g (7.8 oz)',
          protein: 46,
          calories: 380,
          carbs: 0,
          fat: 20,
          confidence: 'high',
          notes: 'Trimmed outer fat, medium-rare pan seared'
        },
        {
          name: 'Roasted Sweet Potato Wedges',
          estimatedPortion: '180g (1 medium potato)',
          protein: 3,
          calories: 160,
          carbs: 38,
          fat: 1,
          confidence: 'high',
          notes: 'Oven roasted skin-on'
        },
        {
          name: 'Charred Asparagus Spears',
          estimatedPortion: '120g (~8 spears)',
          protein: 3,
          calories: 40,
          carbs: 6,
          fat: 1,
          confidence: 'medium',
          notes: 'Light olive oil brushing'
        },
        {
          name: 'Herb Garlic Butter Finish',
          estimatedPortion: '1 pat (~7g)',
          protein: 0,
          calories: 60,
          carbs: 0,
          fat: 7,
          confidence: 'medium',
          notes: 'Melted steak topping'
        }
      ]
    };

    onAnalysisSuccess(sampleAnalysis, selectedImage || '');
    onClose();
  };

  const handleResetImage = () => {
    setSelectedImage(null);
    setErrorMessage(null);
    setIsKeyMissing(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (cameraInputRef.current) cameraInputRef.current.value = '';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full sm:max-w-lg bg-[#0e111a] border border-[#232b3d] rounded-t-3xl sm:rounded-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-[#1b2233] flex items-center justify-between bg-[#131724]">
          <div className="flex items-center gap-2">
            <span className="flex items-center justify-center w-8 h-8 rounded-lg bg-[#a3e635]/20 text-[#a3e635]">
              <Sparkles className="w-4 h-4" />
            </span>
            <div>
              <h3 className="font-bold text-base text-white">AI Diet Photo Scanner</h3>
              <p className="text-xs text-gray-400">Powered by server-side Gemini 3.8 Flash</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-[#202738] text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Hidden inputs */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileChange}
          />
          <input
            ref={cameraInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={handleFileChange}
          />

          {!selectedImage ? (
            /* Upload & Camera Prompt Box */
            <div className="space-y-4">
              <div className="border-2 border-dashed border-[#263147] hover:border-[#a3e635]/60 bg-[#121623]/80 rounded-2xl p-6 text-center transition-all flex flex-col items-center justify-center">
                <div className="w-14 h-14 rounded-2xl bg-[#1b2234] border border-[#2b354d] flex items-center justify-center text-[#a3e635] mb-3 shadow-inner">
                  <Camera className="w-7 h-7 stroke-[2]" />
                </div>
                <h4 className="text-sm font-bold text-white mb-1">
                  Snap or Upload Your Meal
                </h4>
                <p className="text-xs text-gray-400 max-w-xs leading-relaxed mb-4">
                  Hold your phone above your plate in good light. Forge identifies ingredients, portion weights, and macro ratios.
                </p>

                <div className="flex flex-col sm:flex-row gap-2.5 w-full max-w-xs">
                  {/* Camera Button */}
                  <button
                    type="button"
                    onClick={() => cameraInputRef.current?.click()}
                    className="flex-1 py-2.5 px-3 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-black font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-[#a3e635]/20 active:scale-95 transition-all"
                  >
                    <Camera className="w-4 h-4 stroke-[2.5]" />
                    <span>Take Photo</span>
                  </button>

                  {/* Gallery Button */}
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex-1 py-2.5 px-3 rounded-xl bg-[#1a2030] hover:bg-[#252f46] text-white font-bold text-xs border border-[#2c3750] flex items-center justify-center gap-1.5 active:scale-95 transition-all"
                  >
                    <Upload className="w-4 h-4 text-[#a3e635]" />
                    <span>Upload Image</span>
                  </button>
                </div>
              </div>

              {/* Nutrition Estimation Notice */}
              <div className="p-3 bg-[#131724] rounded-xl border border-[#202738] flex items-start gap-2.5 text-xs text-gray-400">
                <Info className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                <p>
                  <strong className="text-gray-200">Visual Estimation:</strong> You will review and can edit all protein, calorie, carb, and fat values in an interactive review screen before anything is committed to your diary.
                </p>
              </div>
            </div>
          ) : (
            /* Selected Image Preview with Scanner Beam Effect */
            <div className="space-y-4">
              <div className="relative rounded-2xl overflow-hidden bg-black border border-[#2a354c] max-h-64 flex items-center justify-center">
                <img
                  src={selectedImage}
                  alt="Meal preview"
                  className="w-full h-64 object-cover"
                />

                {/* Laser scan beam when scanning */}
                {isScanning && (
                  <div className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-[#a3e635] to-transparent shadow-[0_0_15px_#a3e635] animate-scan-beam" />
                )}

                {/* Scanning overlay */}
                {isScanning && (
                  <div className="absolute inset-0 bg-black/60 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center">
                    <Loader2 className="w-8 h-8 text-[#a3e635] animate-spin mb-2" />
                    <span className="text-sm font-bold text-white font-mono">
                      {scanStepMessage || 'Analyzing nutrients...'}
                    </span>
                    <span className="text-xs text-gray-400 mt-1">
                      Estimating protein density & portion sizes
                    </span>
                  </div>
                )}

                {!isScanning && (
                  <button
                    onClick={handleResetImage}
                    className="absolute top-2 right-2 p-1.5 rounded-full bg-black/70 text-gray-300 hover:text-white border border-white/20 transition-colors"
                    title="Change Photo"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Optional User Hint */}
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1">
                  Optional Details (e.g. cooking oil, protein powder scoop)
                </label>
                <input
                  type="text"
                  disabled={isScanning}
                  value={promptHint}
                  onChange={(e) => setPromptHint(e.target.value)}
                  placeholder="e.g. 2 scoops whey with almond milk, steak cooked in butter"
                  className="w-full bg-[#141824] border border-[#232b3d] rounded-xl px-3.5 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-[#a3e635] transition-colors"
                />
              </div>

              {/* Error Box & Missing Key Diagnostics */}
              {errorMessage && (
                <div className="p-3.5 bg-rose-950/40 border border-rose-800/60 rounded-xl space-y-2">
                  <div className="flex items-start gap-2 text-rose-300 text-xs">
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
                    <div>
                      <p className="font-semibold">{errorMessage}</p>
                      {isKeyMissing && (
                        <p className="mt-1 text-gray-300 text-[11px] leading-relaxed">
                          The server cannot run live vision analysis without a valid Gemini key. In AI Studio, open <span className="font-mono text-[#a3e635]">Settings &gt; Secrets</span> and configure <span className="font-mono text-[#a3e635]">GEMINI_API_KEY</span>.
                        </p>
                      )}
                    </div>
                  </div>

                  {isKeyMissing && (
                    <div className="pt-1 flex flex-col sm:flex-row gap-2">
                      <button
                        type="button"
                        onClick={onOpenApkGuide}
                        className="py-1.5 px-3 rounded-lg bg-[#1e2538] hover:bg-[#28324a] text-gray-200 text-xs font-semibold flex items-center justify-center gap-1.5 border border-[#313e59]"
                      >
                        <Key className="w-3.5 h-3.5 text-amber-400" />
                        <span>View Key Setup Guide</span>
                      </button>
                      <button
                        type="button"
                        onClick={handleLoadDemoPlate}
                        className="py-1.5 px-3 rounded-lg bg-[#a3e635]/20 hover:bg-[#a3e635]/30 text-[#a3e635] text-xs font-bold border border-[#a3e635]/40 flex items-center justify-center gap-1.5"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Preview Demo Plate Analysis</span>
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  disabled={isScanning}
                  onClick={handleResetImage}
                  className="flex-1 py-3 rounded-xl bg-[#181d2a] hover:bg-[#202738] text-gray-300 text-xs font-bold border border-[#263145] transition-colors"
                >
                  Choose Different
                </button>
                <button
                  type="button"
                  disabled={isScanning}
                  onClick={handleStartScan}
                  className="flex-1 py-3 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-black text-xs font-extrabold shadow-md shadow-[#a3e635]/20 flex items-center justify-center gap-1.5 active:scale-95 transition-all disabled:opacity-50"
                >
                  {isScanning ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin stroke-[2.5]" />
                      <span>Analyzing...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 stroke-[2.5]" />
                      <span>Analyze Photo</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
