import React from 'react';
import { FoodEntry, DailyGoals } from '../types';
import { getHistorySummaries } from '../services/storage';
import { X, Calendar, Flame, Award, ChevronRight } from 'lucide-react';

interface WeeklyHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  entries: FoodEntry[];
  goals: DailyGoals;
  onSelectDate: (dateKey: string) => void;
}

export const WeeklyHistoryModal: React.FC<WeeklyHistoryModalProps> = ({
  isOpen,
  onClose,
  entries,
  goals,
  onSelectDate
}) => {
  if (!isOpen) return null;

  const history = getHistorySummaries(entries, 7);
  const proteinGoal = goals.protein || 160;

  // Calculate streak: how many consecutive days going backwards from today had protein >= goal
  let streak = 0;
  for (let i = history.length - 1; i >= 0; i--) {
    if (history[i].totalProtein >= proteinGoal) {
      streak++;
    } else {
      break;
    }
  }

  // Calculate weekly total and average
  const totalWeeklyProtein = history.reduce((sum, d) => sum + d.totalProtein, 0);
  const avgProtein = Math.round(totalWeeklyProtein / history.length);

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full sm:max-w-md bg-[#0e111a] border border-[#232b3d] rounded-t-3xl sm:rounded-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-[#1b2233] flex items-center justify-between bg-[#131724]">
          <div className="flex items-center gap-2">
            <span className="flex items-center justify-center w-8 h-8 rounded-lg bg-[#a3e635]/20 text-[#a3e635]">
              <Calendar className="w-4 h-4" />
            </span>
            <div>
              <h3 className="font-bold text-base text-white">7-Day Protein & History</h3>
              <p className="text-xs text-gray-400">Consistency and daily goal tracking</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-[#202738] text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Top Stat Cards: Streak & Average */}
          <div className="grid grid-cols-2 gap-2.5">
            {/* Streak */}
            <div className="p-3.5 rounded-xl bg-gradient-to-br from-[#192233] to-[#121624] border border-[#26354f]">
              <div className="flex items-center gap-1.5 text-xs text-amber-400 font-bold uppercase tracking-wider">
                <Flame className="w-4 h-4 fill-amber-400 text-amber-400" />
                <span>Protein Streak</span>
              </div>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-3xl font-black font-mono text-white">
                  {streak}
                </span>
                <span className="text-xs font-semibold text-gray-400">
                  {streak === 1 ? 'day' : 'days'}
                </span>
              </div>
              <div className="text-[10px] text-gray-400 mt-0.5">
                Target: {proteinGoal}g/day
              </div>
            </div>

            {/* Average */}
            <div className="p-3.5 rounded-xl bg-gradient-to-br from-[#192233] to-[#121624] border border-[#26354f]">
              <div className="flex items-center gap-1.5 text-xs text-[#a3e635] font-bold uppercase tracking-wider">
                <Award className="w-4 h-4 text-[#a3e635]" />
                <span>Daily Average</span>
              </div>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-3xl font-black font-mono text-[#a3e635]">
                  {avgProtein}
                </span>
                <span className="text-xs font-bold text-[#a3e635]">g</span>
              </div>
              <div className="text-[10px] text-gray-400 mt-0.5">
                Total: {totalWeeklyProtein}g logged
              </div>
            </div>
          </div>

          {/* Visual 7-day Bar Comparison */}
          <div className="p-4 bg-[#121622] rounded-2xl border border-[#202738] space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-gray-300">
              <span>Protein vs Daily Goal ({proteinGoal}g)</span>
              <span className="text-[10px] text-gray-500 font-mono">Last 7 Days</span>
            </div>

            <div className="pt-4 flex items-end justify-between gap-2 h-36 border-b border-[#222a3a] pb-2">
              {history.map((day) => {
                const ratio = Math.min((day.totalProtein / proteinGoal), 1.5);
                const heightPercent = Math.max(12, Math.round(ratio * 70));
                const isMet = day.totalProtein >= proteinGoal;

                return (
                  <button
                    key={day.date}
                    onClick={() => {
                      onSelectDate(day.date);
                      onClose();
                    }}
                    className="flex-1 flex flex-col items-center gap-1.5 group h-full justify-end cursor-pointer"
                  >
                    <span className="text-[10px] font-mono font-bold text-gray-400 group-hover:text-white transition-colors">
                      {day.totalProtein}g
                    </span>
                    <div className="w-full max-w-[28px] bg-[#1a2130] rounded-t-lg overflow-hidden flex flex-col justify-end h-24">
                      <div
                        style={{ height: `${heightPercent}%` }}
                        className={`w-full rounded-t-lg transition-all duration-500 ${
                          isMet 
                            ? 'bg-gradient-to-t from-[#65a30d] to-[#a3e635] shadow-[0_0_8px_#a3e635]/50' 
                            : 'bg-gradient-to-t from-[#2c374d] to-[#4b5563]'
                        }`}
                      />
                    </div>
                    <span className="text-[11px] font-semibold text-gray-400 group-hover:text-[#a3e635]">
                      {day.dayLabel}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Day list breakdown */}
          <div className="space-y-1.5">
            <span className="text-xs uppercase font-bold text-gray-400 tracking-wider block px-1">
              Tap Day to View/Edit Diary
            </span>
            <div className="space-y-1.5">
              {history.map((day) => {
                const isMet = day.totalProtein >= proteinGoal;
                return (
                  <button
                    key={day.date}
                    onClick={() => {
                      onSelectDate(day.date);
                      onClose();
                    }}
                    className="w-full p-2.5 rounded-xl bg-[#131722] hover:bg-[#1b2233] border border-[#202738] hover:border-[#a3e635]/40 flex items-center justify-between text-left transition-all"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-white">
                          {day.dayLabel} ({day.date})
                        </span>
                        {isMet ? (
                          <span className="text-[10px] font-bold text-[#a3e635] bg-[#a3e635]/15 px-1.5 py-0.2 rounded border border-[#a3e635]/30">
                            Goal Met ✓
                          </span>
                        ) : (
                          <span className="text-[10px] text-gray-500">
                            {day.entryCount} meals
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] font-mono text-gray-400 mt-0.5">
                        {day.totalCalories} kcal • {day.totalCarbs}g C • {day.totalFat}g F
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <div className="text-right">
                        <div className="text-xs font-mono font-bold text-[#a3e635]">
                          {day.totalProtein}g
                        </div>
                        <div className="text-[10px] text-gray-500">
                          of {proteinGoal}g
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-gray-500" />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
