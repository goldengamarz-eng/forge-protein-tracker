import React from 'react';
import { Camera, Plus, Target, Smartphone, ChevronLeft, ChevronRight, Calendar, Flame } from 'lucide-react';
import { formatDateKey, getTodayKey } from '../services/storage';

interface HeaderProps {
  currentDateKey: string;
  onDateChange: (newDateKey: string) => void;
  onOpenScanner: () => void;
  onOpenManualAdd: () => void;
  onOpenGoals: () => void;
  onOpenHistory: () => void;
  onOpenApkGuide: () => void;
  proteinGoalMet: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentDateKey,
  onDateChange,
  onOpenScanner,
  onOpenManualAdd,
  onOpenGoals,
  onOpenHistory,
  onOpenApkGuide,
  proteinGoalMet
}) => {
  const isToday = currentDateKey === getTodayKey();

  const handlePrevDay = () => {
    const parts = currentDateKey.split('-').map(Number);
    const d = new Date(parts[0], parts[1] - 1, parts[2]);
    d.setDate(d.getDate() - 1);
    onDateChange(formatDateKey(d));
  };

  const handleNextDay = () => {
    const parts = currentDateKey.split('-').map(Number);
    const d = new Date(parts[0], parts[1] - 1, parts[2]);
    d.setDate(d.getDate() + 1);
    onDateChange(formatDateKey(d));
  };

  const handleGoToday = () => {
    onDateChange(getTodayKey());
  };

  // Formatted date string for humans
  const displayDate = React.useMemo(() => {
    if (isToday) return 'Today';
    const parts = currentDateKey.split('-').map(Number);
    const d = new Date(parts[0], parts[1] - 1, parts[2]);
    return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  }, [currentDateKey, isToday]);

  return (
    <header className="sticky top-0 z-30 bg-[#090a0f]/95 backdrop-blur-md border-b border-[#1c222e] px-4 py-3">
      <div className="max-w-3xl mx-auto flex flex-col gap-2.5">
        {/* Top row: Brand & Primary Controls */}
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2.5">
            <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-br from-[#a3e635] to-[#4d7c0f] text-black font-black text-lg shadow-md shadow-[#a3e635]/20">
              <span className="tracking-tighter">⚡</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-white text-base tracking-tight">FORGE</span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-[#a3e635]/15 text-[#a3e635] border border-[#a3e635]/30">
                  PROTEIN
                </span>
              </div>
              <p className="text-[11px] text-gray-400 font-medium">Daily Macro & AI Diet Scanner</p>
            </div>
          </div>

          {/* Right Action Icons */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={onOpenHistory}
              title="7-Day History & Trends"
              className="p-2 rounded-lg bg-[#141824] hover:bg-[#1d2334] text-gray-300 hover:text-white border border-[#232b3d] transition-colors"
            >
              <Calendar className="w-4 h-4 text-[#a3e635]" />
            </button>
            <button
              onClick={onOpenGoals}
              title="Edit Daily Nutrition Targets"
              className="p-2 rounded-lg bg-[#141824] hover:bg-[#1d2334] text-gray-300 hover:text-white border border-[#232b3d] transition-colors"
            >
              <Target className="w-4 h-4 text-[#38bdf8]" />
            </button>
            <button
              onClick={onOpenApkGuide}
              title="Android APK & AI Setup Guide"
              className="p-2 rounded-lg bg-[#141824] hover:bg-[#1d2334] text-gray-300 hover:text-white border border-[#232b3d] transition-colors"
            >
              <Smartphone className="w-4 h-4 text-[#bef264]" />
            </button>
          </div>
        </div>

        {/* Second Row: Date Switcher & Fast Log Buttons */}
        <div className="flex items-center justify-between gap-2 pt-0.5">
          {/* Date Selector */}
          <div className="flex items-center bg-[#131722] border border-[#222a3a] rounded-xl p-0.5 text-xs font-medium">
            <button
              onClick={handlePrevDay}
              className="p-1.5 text-gray-400 hover:text-white transition-colors"
              title="Previous Day"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <button
              onClick={handleGoToday}
              className={`px-2.5 py-1 rounded-lg flex items-center gap-1.5 transition-colors ${
                isToday 
                  ? 'bg-[#1b2233] text-white font-semibold' 
                  : 'text-gray-300 hover:text-white'
              }`}
            >
              <span className="font-mono">{displayDate}</span>
              {proteinGoalMet && (
                <span className="w-2 h-2 rounded-full bg-[#a3e635] shadow-[0_0_8px_#a3e635]" title="Daily Protein Goal Met!" />
              )}
            </button>

            <button
              onClick={handleNextDay}
              className="p-1.5 text-gray-400 hover:text-white transition-colors"
              title="Next Day"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={onOpenScanner}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-black font-bold text-xs shadow-sm shadow-[#a3e635]/30 active:scale-95 transition-all"
            >
              <Camera className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>AI Scan</span>
            </button>

            <button
              onClick={onOpenManualAdd}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-[#1e2535] hover:bg-[#283247] text-white font-semibold text-xs border border-[#2e3a52] active:scale-95 transition-all"
            >
              <Plus className="w-3.5 h-3.5 text-[#a3e635]" />
              <span>Add</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
