import React, { useState, useEffect } from 'react';
import { FoodEntry, MealType } from '../types';
import { HIGH_PROTEIN_STAPLES, QuickStaple } from '../services/storage';
import { X, Check, Calculator, Sparkles } from 'lucide-react';

interface ManualAddFoodModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (entryData: Omit<FoodEntry, 'id' | 'createdAt'>) => void;
  onUpdate?: (entryId: string, entryData: Partial<FoodEntry>) => void;
  dateKey: string;
  defaultMeal?: MealType;
  editingEntry?: FoodEntry | null;
}

export const ManualAddFoodModal: React.FC<ManualAddFoodModalProps> = ({
  isOpen,
  onClose,
  onSave,
  onUpdate,
  dateKey,
  defaultMeal = 'lunch',
  editingEntry = null
}) => {
  const [mealType, setMealType] = useState<MealType>(defaultMeal);
  const [name, setName] = useState('');
  const [portionSize, setPortionSize] = useState('');
  const [quantity, setQuantity] = useState<number>(1);
  const [unit, setUnit] = useState('serving');
  const [protein, setProtein] = useState<string>('');
  const [calories, setCalories] = useState<string>('');
  const [carbs, setCarbs] = useState<string>('');
  const [fat, setFat] = useState<string>('');
  const [notes, setNotes] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  useEffect(() => {
    if (editingEntry) {
      setMealType(editingEntry.mealType);
      setName(editingEntry.name);
      setPortionSize(editingEntry.portionSize || '');
      setQuantity(editingEntry.quantity || 1);
      setUnit(editingEntry.unit || 'serving');
      setProtein(String(editingEntry.protein));
      setCalories(String(editingEntry.calories));
      setCarbs(String(editingEntry.carbs));
      setFat(String(editingEntry.fat));
      setNotes(editingEntry.notes || '');
    } else {
      setMealType(defaultMeal);
      setName('');
      setPortionSize('1 serving');
      setQuantity(1);
      setUnit('serving');
      setProtein('');
      setCalories('');
      setCarbs('');
      setFat('');
      setNotes('');
    }
  }, [editingEntry, defaultMeal, isOpen]);

  if (!isOpen) return null;

  const handleSelectStaple = (staple: QuickStaple) => {
    setName(staple.name);
    setPortionSize(staple.portion);
    setProtein(String(staple.protein));
    setCalories(String(staple.calories));
    setCarbs(String(staple.carbs));
    setFat(String(staple.fat));
    setQuantity(1);
    setUnit('serving');
  };

  const handleAutoCalcCalories = () => {
    const p = Number(protein) || 0;
    const c = Number(carbs) || 0;
    const f = Number(fat) || 0;
    const calculated = Math.round(p * 4 + c * 4 + f * 9);
    setCalories(String(calculated));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const parsedProtein = Math.max(0, Number(protein) || 0);
    const parsedCarbs = Math.max(0, Number(carbs) || 0);
    const parsedFat = Math.max(0, Number(fat) || 0);
    let parsedCalories = Math.max(0, Number(calories) || 0);

    // Auto calculate calories if left blank
    if (parsedCalories === 0 && (parsedProtein > 0 || parsedCarbs > 0 || parsedFat > 0)) {
      parsedCalories = Math.round(parsedProtein * 4 + parsedCarbs * 4 + parsedFat * 9);
    }

    const payload = {
      date: dateKey,
      mealType,
      name: name.trim(),
      portionSize: portionSize.trim() || '1 serving',
      quantity: Number(quantity) || 1,
      unit: unit || 'serving',
      protein: parsedProtein,
      calories: parsedCalories,
      carbs: parsedCarbs,
      fat: parsedFat,
      notes: notes.trim()
    };

    if (editingEntry && onUpdate) {
      onUpdate(editingEntry.id, payload);
    } else {
      onSave(payload);
    }

    onClose();
  };

  const categories = ['All', 'Poultry', 'Fish', 'Meat', 'Dairy', 'Eggs', 'Supplements'];
  const filteredStaples = selectedCategory === 'All' 
    ? HIGH_PROTEIN_STAPLES 
    : HIGH_PROTEIN_STAPLES.filter(s => s.category === selectedCategory);

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="w-full sm:max-w-md bg-[#10131d] border border-[#232b3d] rounded-t-3xl sm:rounded-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="p-4 border-b border-[#1c2333] flex items-center justify-between bg-[#141824]/80">
          <div>
            <h3 className="font-bold text-base text-white">
              {editingEntry ? 'Edit Food Entry' : 'Add Food Item'}
            </h3>
            <p className="text-xs text-gray-400">Log manual portion and macronutrients</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-[#202738] text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Quick Staple Selector Pills (only when creating new) */}
          {!editingEntry && (
            <div className="space-y-2 bg-[#141824]/60 p-3 rounded-xl border border-[#20283b]">
              <div className="flex items-center justify-between text-xs font-semibold text-gray-300">
                <span className="flex items-center gap-1.5 text-[#a3e635]">
                  <Sparkles className="w-3.5 h-3.5" /> Quick High-Protein Staples
                </span>
                <span className="text-[10px] text-gray-500 font-mono">1-tap fill</span>
              </div>

              {/* Category pills */}
              <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                {categories.map(cat => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-2 py-0.5 rounded-md text-[10px] font-semibold transition-colors whitespace-nowrap ${
                      selectedCategory === cat 
                        ? 'bg-[#a3e635] text-black' 
                        : 'bg-[#1b2233] text-gray-400 hover:text-white'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {/* Staples Grid */}
              <div className="grid grid-cols-2 gap-1.5 max-h-32 overflow-y-auto pr-1">
                {filteredStaples.slice(0, 8).map((staple) => (
                  <button
                    key={staple.name}
                    type="button"
                    onClick={() => handleSelectStaple(staple)}
                    className="text-left p-2 rounded-lg bg-[#181f2d] hover:bg-[#222b3e] border border-[#242f44] hover:border-[#a3e635]/40 transition-colors"
                  >
                    <div className="text-xs font-bold text-gray-200 truncate">{staple.name}</div>
                    <div className="flex items-center justify-between text-[10px] font-mono mt-0.5">
                      <span className="text-[#a3e635] font-bold">{staple.protein}g P</span>
                      <span className="text-gray-400">{staple.calories} kcal</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Meal Type Radio Selector */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-400 mb-1.5">
              Meal Period
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {(['breakfast', 'lunch', 'dinner', 'snack'] as MealType[]).map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setMealType(type)}
                  className={`py-2 px-1 text-center rounded-xl text-xs font-semibold capitalize transition-all ${
                    mealType === type
                      ? 'bg-[#a3e635] text-black font-bold shadow-sm shadow-[#a3e635]/20'
                      : 'bg-[#161a26] text-gray-300 border border-[#232a3a] hover:bg-[#1e2536]'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          {/* Food Name */}
          <div>
            <label className="block text-xs font-semibold text-gray-300 mb-1">
              Food / Meal Name *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Grilled Chicken Breast, Whey Shake"
              className="w-full bg-[#141824] border border-[#232b3d] rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#a3e635] transition-colors"
            />
          </div>

          {/* Portion and Quantity */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-gray-300 mb-1">
                Portion Description
              </label>
              <input
                type="text"
                value={portionSize}
                onChange={(e) => setPortionSize(e.target.value)}
                placeholder="e.g. 200g, 1 breast"
                className="w-full bg-[#141824] border border-[#232b3d] rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#a3e635] transition-colors"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-300 mb-1">
                Servings Multiplier
              </label>
              <input
                type="number"
                step="0.1"
                min="0.1"
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value) || 1)}
                className="w-full bg-[#141824] border border-[#232b3d] rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-gray-500 font-mono focus:outline-none focus:border-[#a3e635] transition-colors"
              />
            </div>
          </div>

          {/* Macronutrients Grid */}
          <div className="p-3 bg-[#131722] rounded-xl border border-[#202738] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-gray-300">
                Macronutrients (per serving)
              </span>
              <button
                type="button"
                onClick={handleAutoCalcCalories}
                className="inline-flex items-center gap-1 text-[11px] text-[#a3e635] hover:text-[#bef264] font-semibold"
                title="Calculate calories from 4P + 4C + 9F"
              >
                <Calculator className="w-3.5 h-3.5" />
                <span>Auto-Calc Cals</span>
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {/* Protein Input */}
              <div className="bg-[#181e2b] p-2.5 rounded-lg border border-[#283347] focus-within:border-[#a3e635]">
                <label className="block text-[10px] uppercase font-bold text-[#a3e635] mb-0.5">
                  Protein (g) *
                </label>
                <input
                  type="number"
                  step="0.5"
                  min="0"
                  required
                  value={protein}
                  onChange={(e) => setProtein(e.target.value)}
                  placeholder="0"
                  className="w-full bg-transparent font-mono font-bold text-base text-white focus:outline-none"
                />
              </div>

              {/* Calories Input */}
              <div className="bg-[#181e2b] p-2.5 rounded-lg border border-[#283347] focus-within:border-amber-400">
                <label className="block text-[10px] uppercase font-bold text-amber-400 mb-0.5">
                  Calories (kcal)
                </label>
                <input
                  type="number"
                  step="1"
                  min="0"
                  value={calories}
                  onChange={(e) => setCalories(e.target.value)}
                  placeholder="0"
                  className="w-full bg-transparent font-mono font-bold text-base text-white focus:outline-none"
                />
              </div>

              {/* Carbs Input */}
              <div className="bg-[#181e2b] p-2.5 rounded-lg border border-[#283347] focus-within:border-sky-400">
                <label className="block text-[10px] uppercase font-bold text-sky-400 mb-0.5">
                  Carbs (g)
                </label>
                <input
                  type="number"
                  step="0.5"
                  min="0"
                  value={carbs}
                  onChange={(e) => setCarbs(e.target.value)}
                  placeholder="0"
                  className="w-full bg-transparent font-mono font-bold text-base text-white focus:outline-none"
                />
              </div>

              {/* Fat Input */}
              <div className="bg-[#181e2b] p-2.5 rounded-lg border border-[#283347] focus-within:border-orange-400">
                <label className="block text-[10px] uppercase font-bold text-orange-400 mb-0.5">
                  Fat (g)
                </label>
                <input
                  type="number"
                  step="0.5"
                  min="0"
                  value={fat}
                  onChange={(e) => setFat(e.target.value)}
                  placeholder="0"
                  className="w-full bg-transparent font-mono font-bold text-base text-white focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-gray-400 mb-1">
              Optional Notes / Ingredients
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Cooked in 1 tsp olive oil, post-leg day meal"
              className="w-full bg-[#141824] border border-[#232b3d] rounded-xl px-3 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-[#a3e635] transition-colors"
            />
          </div>

          {/* Actions */}
          <div className="pt-2 flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 rounded-xl bg-[#181d2a] hover:bg-[#202738] text-gray-300 text-xs font-bold border border-[#263145] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-3 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-black text-xs font-extrabold shadow-md shadow-[#a3e635]/20 flex items-center justify-center gap-1.5 transition-all"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              <span>{editingEntry ? 'Update Entry' : 'Log Food to Diary'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
