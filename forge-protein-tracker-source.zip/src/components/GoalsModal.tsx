import React, { useState } from 'react';
import { DailyGoals, GoalPreset } from '../types';
import { X, Check, Target, Dumbbell, Flame, Sparkles } from 'lucide-react';

interface GoalsModalProps {
  isOpen: boolean;
  onClose: () => void;
  goals: DailyGoals;
  onSaveGoals: (updatedGoals: DailyGoals) => void;
}

export const GoalsModal: React.FC<GoalsModalProps> = ({
  isOpen,
  onClose,
  goals,
  onSaveGoals
}) => {
  const [protein, setProtein] = useState<string>(String(goals.protein));
  const [calories, setCalories] = useState<string>(String(goals.calories));
  const [carbs, setCarbs] = useState<string>(String(goals.carbs));
  const [fat, setFat] = useState<string>(String(goals.fat));
  const [bodyWeightKg, setBodyWeightKg] = useState<string>(String(goals.bodyWeightKg || 75));
  const [goalType, setGoalType] = useState<GoalPreset>(goals.goalType || 'hypertrophy');

  if (!isOpen) return null;

  // Preset definitions
  const applyPreset = (preset: GoalPreset, weight: number) => {
    setGoalType(preset);
    const bw = weight > 0 ? weight : 75;

    if (preset === 'hypertrophy') {
      // 2.2g protein / kg bodyweight
      const p = Math.round(bw * 2.2);
      const c = Math.round(bw * 3.0);
      const f = Math.round(bw * 0.85);
      const cals = Math.round(p * 4 + c * 4 + f * 9);
      setProtein(String(p));
      setCarbs(String(c));
      setFat(String(f));
      setCalories(String(cals));
    } else if (preset === 'fat_loss') {
      // High protein sparing lean mass during caloric deficit
      const p = Math.round(bw * 2.4);
      const c = Math.round(bw * 1.8);
      const f = Math.round(bw * 0.7);
      const cals = Math.round(p * 4 + c * 4 + f * 9);
      setProtein(String(p));
      setCarbs(String(c));
      setFat(String(f));
      setCalories(String(cals));
    } else if (preset === 'lean_bulk') {
      // 2.0g protein / kg with carbohydrate surplus
      const p = Math.round(bw * 2.0);
      const c = Math.round(bw * 4.2);
      const f = Math.round(bw * 1.0);
      const cals = Math.round(p * 4 + c * 4 + f * 9);
      setProtein(String(p));
      setCarbs(String(c));
      setFat(String(f));
      setCalories(String(cals));
    } else if (preset === 'maintenance') {
      // 1.8g protein / kg
      const p = Math.round(bw * 1.8);
      const c = Math.round(bw * 2.8);
      const f = Math.round(bw * 0.9);
      const cals = Math.round(p * 4 + c * 4 + f * 9);
      setProtein(String(p));
      setCarbs(String(c));
      setFat(String(f));
      setCalories(String(cals));
    }
  };

  const handleWeightChange = (newWeightStr: string) => {
    setBodyWeightKg(newWeightStr);
    const w = Number(newWeightStr);
    if (w > 30 && w < 250 && goalType !== 'custom') {
      applyPreset(goalType, w);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: DailyGoals = {
      protein: Math.max(10, Number(protein) || 160),
      calories: Math.max(500, Number(calories) || 2000),
      carbs: Math.max(0, Number(carbs) || 200),
      fat: Math.max(0, Number(fat) || 60),
      bodyWeightKg: Number(bodyWeightKg) || 75,
      goalType,
      updatedAt: new Date().toISOString()
    };
    onSaveGoals(updated);
    onClose();
  };

  const pNum = Number(protein) || 0;
  const cNum = Number(carbs) || 0;
  const fNum = Number(fat) || 0;
  const calculatedCals = Math.round(pNum * 4 + cNum * 4 + fNum * 9);

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full sm:max-w-md bg-[#0e111a] border border-[#232b3d] rounded-t-3xl sm:rounded-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-[#1b2233] flex items-center justify-between bg-[#131724]">
          <div className="flex items-center gap-2">
            <span className="flex items-center justify-center w-8 h-8 rounded-lg bg-[#a3e635]/20 text-[#a3e635]">
              <Target className="w-4 h-4" />
            </span>
            <div>
              <h3 className="font-bold text-base text-white">Daily Nutrition Targets</h3>
              <p className="text-xs text-gray-400">Configure your daily protein & macro goals</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-[#202738] text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Presets */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-400">
              Training Focus Preset
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              {[
                { id: 'hypertrophy', label: 'Hypertrophy', sub: '2.2g P / kg' },
                { id: 'fat_loss', label: 'Lean Cut', sub: 'High P Deficit' },
                { id: 'lean_bulk', label: 'Lean Bulk', sub: 'Surplus Carbs' },
                { id: 'maintenance', label: 'Maintenance', sub: 'Athletic Balance' },
              ].map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => applyPreset(preset.id as GoalPreset, Number(bodyWeightKg) || 75)}
                  className={`p-2.5 rounded-xl text-left border transition-all ${
                    goalType === preset.id
                      ? 'bg-[#a3e635]/15 border-[#a3e635] text-white shadow-sm shadow-[#a3e635]/10'
                      : 'bg-[#141824] border-[#222a3a] text-gray-400 hover:text-white'
                  }`}
                >
                  <div className="text-xs font-bold">{preset.label}</div>
                  <div className="text-[10px] text-gray-500 font-mono">{preset.sub}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Body Weight Input Helper */}
          <div className="p-3 bg-[#131724] rounded-xl border border-[#202738] flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-gray-300 block">Your Body Weight</span>
              <span className="text-[10px] text-gray-500">Auto-scales optimal protein targets</span>
            </div>
            <div className="flex items-center gap-1.5">
              <input
                type="number"
                step="0.5"
                min="35"
                max="250"
                value={bodyWeightKg}
                onChange={(e) => handleWeightChange(e.target.value)}
                className="w-16 bg-[#1a2130] border border-[#2b354a] rounded-lg px-2 py-1 text-center font-mono font-bold text-sm text-white focus:outline-none focus:border-[#a3e635]"
              />
              <span className="text-xs text-gray-400 font-bold">kg</span>
            </div>
          </div>

          {/* Macro Inputs */}
          <div className="space-y-3">
            {/* Protein Target (Primary) */}
            <div className="p-3.5 rounded-xl bg-gradient-to-r from-[#171f2b] to-[#121622] border-2 border-[#a3e635]/40 flex items-center justify-between">
              <div>
                <label className="text-xs uppercase font-extrabold text-[#a3e635] tracking-wider block">
                  Daily Protein Target *
                </label>
                <span className="text-[11px] text-gray-400">Essential for muscle repair & retention</span>
              </div>
              <div className="flex items-center gap-1.5">
                <input
                  type="number"
                  step="5"
                  min="20"
                  max="450"
                  required
                  value={protein}
                  onChange={(e) => {
                    setProtein(e.target.value);
                    setGoalType('custom');
                  }}
                  className="w-20 bg-[#1e2738] border border-[#a3e635]/60 rounded-xl px-2.5 py-1.5 text-center font-mono font-black text-lg text-[#a3e635] focus:outline-none"
                />
                <span className="font-bold text-sm text-[#a3e635]">g</span>
              </div>
            </div>

            {/* Calories Target */}
            <div className="p-3 rounded-xl bg-[#141824] border border-[#222a3a] flex items-center justify-between">
              <div>
                <label className="text-xs uppercase font-bold text-amber-400 tracking-wider block">
                  Daily Calories
                </label>
                <span className="text-[10px] text-gray-500 font-mono">Macro sum: {calculatedCals} kcal</span>
              </div>
              <div className="flex items-center gap-1.5">
                <input
                  type="number"
                  step="50"
                  min="800"
                  max="8000"
                  required
                  value={calories}
                  onChange={(e) => {
                    setCalories(e.target.value);
                    setGoalType('custom');
                  }}
                  className="w-24 bg-[#1b2233] border border-[#2c374d] rounded-xl px-2.5 py-1.5 text-center font-mono font-bold text-base text-white focus:outline-none focus:border-amber-400"
                />
                <span className="font-bold text-xs text-gray-400">kcal</span>
              </div>
            </div>

            {/* Carbs & Fat Grid */}
            <div className="grid grid-cols-2 gap-2.5">
              {/* Carbs */}
              <div className="p-3 rounded-xl bg-[#141824] border border-[#222a3a]">
                <label className="text-[10px] uppercase font-bold text-sky-400 tracking-wider block mb-1">
                  Carbs (g)
                </label>
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    step="5"
                    min="0"
                    max="800"
                    value={carbs}
                    onChange={(e) => {
                      setCarbs(e.target.value);
                      setGoalType('custom');
                    }}
                    className="w-full bg-[#1b2233] border border-[#2c374d] rounded-lg px-2.5 py-1 text-center font-mono font-bold text-sm text-white focus:outline-none focus:border-sky-400"
                  />
                  <span className="text-xs text-gray-400">g</span>
                </div>
              </div>

              {/* Fat */}
              <div className="p-3 rounded-xl bg-[#141824] border border-[#222a3a]">
                <label className="text-[10px] uppercase font-bold text-orange-400 tracking-wider block mb-1">
                  Fat (g)
                </label>
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    step="5"
                    min="0"
                    max="300"
                    value={fat}
                    onChange={(e) => {
                      setFat(e.target.value);
                      setGoalType('custom');
                    }}
                    className="w-full bg-[#1b2233] border border-[#2c374d] rounded-lg px-2.5 py-1 text-center font-mono font-bold text-sm text-white focus:outline-none focus:border-orange-400"
                  />
                  <span className="text-xs text-gray-400">g</span>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 rounded-xl bg-[#181d2a] hover:bg-[#202738] text-gray-300 text-xs font-bold border border-[#263145] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-3 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-black text-xs font-extrabold shadow-md shadow-[#a3e635]/20 flex items-center justify-center gap-1.5 active:scale-95 transition-all"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              <span>Save Nutrition Goals</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
