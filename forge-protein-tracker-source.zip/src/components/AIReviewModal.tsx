import React, { useState, useEffect } from 'react';
import { AIPhotoAnalysisResult, AIAnalyzedItem, MealType, FoodEntry } from '../types';
import { Check, X, Plus, Trash2, ShieldAlert, Sparkles, Flame, Zap } from 'lucide-react';

interface AIReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  analysis: AIPhotoAnalysisResult | null;
  photoDataUrl?: string;
  dateKey: string;
  onConfirmAndLog: (entries: Array<Omit<FoodEntry, 'id' | 'createdAt'>>) => void;
}

export const AIReviewModal: React.FC<AIReviewModalProps> = ({
  isOpen,
  onClose,
  analysis,
  photoDataUrl,
  dateKey,
  onConfirmAndLog
}) => {
  const [mealType, setMealType] = useState<MealType>('lunch');
  const [dishTitle, setDishTitle] = useState('');
  const [items, setItems] = useState<AIAnalyzedItem[]>([]);
  const [logAsCombined, setLogAsCombined] = useState(true);

  // Set default meal type based on hour
  useEffect(() => {
    const hour = new Date().getHours();
    if (hour < 11) setMealType('breakfast');
    else if (hour < 16) setMealType('lunch');
    else if (hour < 21) setMealType('dinner');
    else setMealType('snack');
  }, []);

  useEffect(() => {
    if (analysis) {
      setDishTitle(analysis.dishTitle || 'Estimated Meal');
      setItems(analysis.items && analysis.items.length > 0 ? [...analysis.items] : [
        {
          name: analysis.dishTitle || 'Meal Item',
          estimatedPortion: '1 serving',
          protein: analysis.totalProtein || 0,
          calories: analysis.totalCalories || 0,
          carbs: analysis.totalCarbs || 0,
          fat: analysis.totalFat || 0,
          confidence: analysis.confidence || 'medium',
          notes: ''
        }
      ]);
    }
  }, [analysis]);

  if (!isOpen || !analysis) return null;

  // Recalculate totals dynamically from items
  const totals = items.reduce(
    (acc, curr) => ({
      protein: acc.protein + (Number(curr.protein) || 0),
      calories: acc.calories + (Number(curr.calories) || 0),
      carbs: acc.carbs + (Number(curr.carbs) || 0),
      fat: acc.fat + (Number(curr.fat) || 0),
    }),
    { protein: 0, calories: 0, carbs: 0, fat: 0 }
  );

  const handleUpdateItem = (index: number, field: keyof AIAnalyzedItem, value: any) => {
    setItems((prev) => {
      const copy = [...prev];
      copy[index] = {
        ...copy[index],
        [field]: value
      };
      return copy;
    });
  };

  const handleRemoveItem = (index: number) => {
    setItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleAddItem = () => {
    setItems((prev) => [
      ...prev,
      {
        name: 'Extra Item / Side',
        estimatedPortion: '1 serving',
        protein: 5,
        calories: 80,
        carbs: 10,
        fat: 2,
        confidence: 'medium',
        notes: ''
      }
    ]);
  };

  const handleConfirm = () => {
    if (items.length === 0) return;

    if (logAsCombined) {
      // Log as single cohesive meal entry with itemized notes
      const ingredientsSummary = items.map(i => `${i.name} (${i.estimatedPortion})`).join(', ');
      const singleEntry: Omit<FoodEntry, 'id' | 'createdAt'> = {
        date: dateKey,
        mealType,
        name: dishTitle.trim() || 'AI Scanned Meal',
        portionSize: `${items.length} plate items`,
        quantity: 1,
        unit: 'meal',
        protein: totals.protein,
        calories: totals.calories,
        carbs: totals.carbs,
        fat: totals.fat,
        scannedFromPhoto: true,
        photoThumbnail: photoDataUrl ? photoDataUrl.slice(0, 1000) : undefined,
        notes: ingredientsSummary
      };
      onConfirmAndLog([singleEntry]);
    } else {
      // Log each item as individual diary row
      const multipleEntries: Array<Omit<FoodEntry, 'id' | 'createdAt'>> = items.map((item) => ({
        date: dateKey,
        mealType,
        name: item.name,
        portionSize: item.estimatedPortion || '1 serving',
        quantity: 1,
        unit: 'portion',
        protein: Math.round(Number(item.protein) || 0),
        calories: Math.round(Number(item.calories) || 0),
        carbs: Math.round(Number(item.carbs) || 0),
        fat: Math.round(Number(item.fat) || 0),
        scannedFromPhoto: true,
        notes: item.notes || `From: ${dishTitle}`
      }));
      onConfirmAndLog(multipleEntries);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full sm:max-w-xl bg-[#0e111a] border border-[#232b3d] rounded-t-3xl sm:rounded-2xl max-h-[94vh] flex flex-col shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-[#1b2233] flex items-center justify-between bg-[#131724]">
          <div className="flex items-center gap-2">
            <span className="flex items-center justify-center w-8 h-8 rounded-lg bg-[#a3e635]/20 text-[#a3e635]">
              <Sparkles className="w-4 h-4" />
            </span>
            <div>
              <h3 className="font-bold text-base text-white">Review & Edit AI Estimation</h3>
              <p className="text-xs text-gray-400">Tweak portions and nutrition before logging</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-[#202738] text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Disclaimer Banner */}
          <div className="p-3 bg-amber-950/30 border border-amber-800/40 rounded-xl flex items-start gap-2.5 text-xs text-amber-200">
            <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">AI Nutrition Estimate:</span> All weights and macros are visual approximations based on camera perspective. Please adjust below if your portions differ.
            </div>
          </div>

          {/* Meal Target Selector */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-400 mb-1.5">
              Assign to Meal
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {(['breakfast', 'lunch', 'dinner', 'snack'] as MealType[]).map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setMealType(type)}
                  className={`py-2 px-1 text-center rounded-xl text-xs font-semibold capitalize transition-all ${
                    mealType === type
                      ? 'bg-[#a3e635] text-black font-bold shadow-sm shadow-[#a3e635]/20'
                      : 'bg-[#161a26] text-gray-300 border border-[#232a3a] hover:bg-[#1e2536]'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          {/* Dish Name */}
          <div>
            <label className="block text-xs font-semibold text-gray-300 mb-1">
              Meal Name
            </label>
            <input
              type="text"
              value={dishTitle}
              onChange={(e) => setDishTitle(e.target.value)}
              className="w-full bg-[#141824] border border-[#232b3d] rounded-xl px-3.5 py-2.5 text-sm text-white font-medium focus:outline-none focus:border-[#a3e635] transition-colors"
            />
          </div>

          {/* Live Calculated Totals Banner */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-br from-[#161b29] to-[#121520] border border-[#252f44] flex items-center justify-between">
            <div>
              <div className="text-[11px] uppercase font-bold text-gray-400 tracking-wider">
                Total Estimated Protein
              </div>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-3xl font-black font-mono text-[#a3e635]">
                  {totals.protein}
                </span>
                <span className="text-sm font-bold text-[#a3e635]">g</span>
              </div>
            </div>

            <div className="flex items-center gap-3 text-right">
              <div>
                <div className="text-[10px] uppercase font-bold text-amber-400">Calories</div>
                <div className="text-sm font-bold font-mono text-white">{totals.calories} kcal</div>
              </div>
              <div>
                <div className="text-[10px] uppercase font-bold text-sky-400">Carbs</div>
                <div className="text-sm font-bold font-mono text-white">{totals.carbs}g</div>
              </div>
              <div>
                <div className="text-[10px] uppercase font-bold text-orange-400">Fat</div>
                <div className="text-sm font-bold font-mono text-white">{totals.fat}g</div>
              </div>
            </div>
          </div>

          {/* Itemized Foods (Editable) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-gray-400">
                Detected Plate Components ({items.length})
              </span>
              <button
                type="button"
                onClick={handleAddItem}
                className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#a3e635] hover:text-[#bef264]"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Item</span>
              </button>
            </div>

            <div className="space-y-2.5">
              {items.map((item, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-xl bg-[#141824] border border-[#21293a] space-y-2.5"
                >
                  <div className="flex items-center justify-between gap-2">
                    <input
                      type="text"
                      value={item.name}
                      onChange={(e) => handleUpdateItem(idx, 'name', e.target.value)}
                      placeholder="Ingredient / Item name"
                      className="flex-1 bg-transparent text-sm font-bold text-white border-b border-transparent focus:border-[#a3e635] focus:outline-none py-0.5"
                    />
                    <button
                      type="button"
                      onClick={() => handleRemoveItem(idx)}
                      className="p-1 text-gray-500 hover:text-rose-400 rounded transition-colors"
                      title="Remove Item"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <label className="text-[10px] text-gray-400 font-medium">Estimated Weight / Portion</label>
                      <input
                        type="text"
                        value={item.estimatedPortion}
                        onChange={(e) => handleUpdateItem(idx, 'estimatedPortion', e.target.value)}
                        placeholder="e.g. 180g (6 oz)"
                        className="w-full bg-[#1b2233] border border-[#273247] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-[#a3e635]"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-gray-400 font-medium">Portion Notes</label>
                      <input
                        type="text"
                        value={item.notes || ''}
                        onChange={(e) => handleUpdateItem(idx, 'notes', e.target.value)}
                        placeholder="e.g. skinless, grilled"
                        className="w-full bg-[#1b2233] border border-[#273247] rounded-lg px-2.5 py-1.5 text-xs text-gray-300 focus:outline-none focus:border-[#a3e635]"
                      />
                    </div>
                  </div>

                  {/* 4 Macro inputs per item */}
                  <div className="grid grid-cols-4 gap-1.5 pt-1">
                    <div className="bg-[#1b2233] p-1.5 rounded-lg border border-[#28344a] text-center">
                      <span className="text-[9px] uppercase font-bold text-[#a3e635] block">Protein</span>
                      <input
                        type="number"
                        min="0"
                        value={item.protein}
                        onChange={(e) => handleUpdateItem(idx, 'protein', Number(e.target.value) || 0)}
                        className="w-full text-center bg-transparent font-mono font-bold text-xs text-white focus:outline-none"
                      />
                    </div>

                    <div className="bg-[#1b2233] p-1.5 rounded-lg border border-[#28344a] text-center">
                      <span className="text-[9px] uppercase font-bold text-amber-400 block">Calories</span>
                      <input
                        type="number"
                        min="0"
                        value={item.calories}
                        onChange={(e) => handleUpdateItem(idx, 'calories', Number(e.target.value) || 0)}
                        className="w-full text-center bg-transparent font-mono font-bold text-xs text-white focus:outline-none"
                      />
                    </div>

                    <div className="bg-[#1b2233] p-1.5 rounded-lg border border-[#28344a] text-center">
                      <span className="text-[9px] uppercase font-bold text-sky-400 block">Carbs</span>
                      <input
                        type="number"
                        min="0"
                        value={item.carbs}
                        onChange={(e) => handleUpdateItem(idx, 'carbs', Number(e.target.value) || 0)}
                        className="w-full text-center bg-transparent font-mono font-bold text-xs text-white focus:outline-none"
                      />
                    </div>

                    <div className="bg-[#1b2233] p-1.5 rounded-lg border border-[#28344a] text-center">
                      <span className="text-[9px] uppercase font-bold text-orange-400 block">Fat</span>
                      <input
                        type="number"
                        min="0"
                        value={item.fat}
                        onChange={(e) => handleUpdateItem(idx, 'fat', Number(e.target.value) || 0)}
                        className="w-full text-center bg-transparent font-mono font-bold text-xs text-white focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Logging style option */}
          <div className="p-3 bg-[#131724] rounded-xl border border-[#202738] flex items-center justify-between text-xs">
            <span className="text-gray-300 font-medium">Log format:</span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setLogAsCombined(true)}
                className={`px-2.5 py-1 rounded-lg font-semibold transition-colors ${
                  logAsCombined ? 'bg-[#a3e635] text-black font-bold' : 'bg-[#1b2233] text-gray-400'
                }`}
              >
                1 Combined Meal
              </button>
              <button
                type="button"
                onClick={() => setLogAsCombined(false)}
                className={`px-2.5 py-1 rounded-lg font-semibold transition-colors ${
                  !logAsCombined ? 'bg-[#a3e635] text-black font-bold' : 'bg-[#1b2233] text-gray-400'
                }`}
              >
                Separate Items
              </button>
            </div>
          </div>

          {/* Confirmation Actions */}
          <div className="pt-2 flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 rounded-xl bg-[#181d2a] hover:bg-[#202738] text-gray-300 text-xs font-bold border border-[#263145] transition-colors"
            >
              Discard
            </button>
            <button
              type="button"
              onClick={handleConfirm}
              className="flex-1 py-3 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-black text-xs font-extrabold shadow-md shadow-[#a3e635]/20 flex items-center justify-center gap-1.5 active:scale-95 transition-all"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              <span>Add to Today</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
