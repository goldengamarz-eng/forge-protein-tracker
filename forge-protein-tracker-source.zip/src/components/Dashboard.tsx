import React from 'react';
import { DailyTotals, DailyGoals } from '../types';
import { Flame, Dumbbell, Zap, Award } from 'lucide-react';

interface DashboardProps {
  totals: DailyTotals;
  goals: DailyGoals;
  onOpenGoals: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ totals, goals, onOpenGoals }) => {
  // Protein calculation
  const proteinCurrent = Math.round(totals.protein);
  const proteinGoal = goals.protein;
  const proteinPercent = Math.min(Math.round((proteinCurrent / (proteinGoal || 1)) * 100), 100);
  const proteinRemaining = Math.max(0, proteinGoal - proteinCurrent);

  // Calories calculation
  const caloriesCurrent = Math.round(totals.calories);
  const caloriesGoal = goals.calories;
  const caloriesPercent = Math.min(Math.round((caloriesCurrent / (caloriesGoal || 1)) * 100), 100);
  const caloriesRemaining = Math.max(0, caloriesGoal - caloriesCurrent);

  // Carbs calculation
  const carbsCurrent = Math.round(totals.carbs);
  const carbsGoal = goals.carbs;
  const carbsPercent = Math.min(Math.round((carbsCurrent / (carbsGoal || 1)) * 100), 100);

  // Fat calculation
  const fatCurrent = Math.round(totals.fat);
  const fatGoal = goals.fat;
  const fatPercent = Math.min(Math.round((fatCurrent / (fatGoal || 1)) * 100), 100);

  // Macro calorie contributions
  const proteinKcal = proteinCurrent * 4;
  const carbsKcal = carbsCurrent * 4;
  const fatKcal = fatCurrent * 9;
  const totalMacroKcal = proteinKcal + carbsKcal + fatKcal || 1;

  const proteinRatio = Math.round((proteinKcal / totalMacroKcal) * 100);
  const carbsRatio = Math.round((carbsKcal / totalMacroKcal) * 100);
  const fatRatio = Math.max(0, 100 - proteinRatio - carbsRatio);

  const isProteinTargetMet = proteinCurrent >= proteinGoal;

  return (
    <section className="space-y-3.5">
      {/* Primary Hero: High-Impact Protein Progress Card */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#121622] via-[#10131d] to-[#0c0e14] border border-[#232b3d] p-5 shadow-lg shadow-black/40">
        {/* Glow accent in top right */}
        <div className="absolute -top-12 -right-12 w-36 h-36 bg-[#a3e635]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="flex items-center justify-center w-6 h-6 rounded-lg bg-[#a3e635]/20 text-[#a3e635]">
                <Dumbbell className="w-3.5 h-3.5" />
              </span>
              <span className="text-xs uppercase font-extrabold tracking-wider text-gray-400">
                Primary Goal
              </span>
            </div>
            <h2 className="text-sm font-semibold text-white mt-1">Daily Protein Intake</h2>
          </div>

          {/* Goal status badge */}
          <button 
            onClick={onOpenGoals}
            className={`px-2.5 py-1 rounded-full text-[11px] font-bold border transition-colors ${
              isProteinTargetMet
                ? 'bg-[#a3e635]/20 text-[#a3e635] border-[#a3e635]/40 animate-pulse'
                : 'bg-[#181f2f] text-gray-300 border-[#2b354c] hover:border-[#a3e635]/50'
            }`}
          >
            {isProteinTargetMet ? 'Target Smashed! 🎯' : `${proteinRemaining}g remaining`}
          </button>
        </div>

        {/* Big Protein Numbers */}
        <div className="mt-4 flex items-baseline justify-between">
          <div className="flex items-baseline gap-1.5">
            <span className="text-4xl sm:text-5xl font-black font-mono text-white tracking-tight">
              {proteinCurrent}
            </span>
            <span className="text-xl sm:text-2xl font-bold font-mono text-[#a3e635]">
              g
            </span>
            <span className="text-sm font-medium text-gray-500 ml-1">
              / {proteinGoal}g goal
            </span>
          </div>

          <div className="text-right">
            <span className="text-2xl font-black font-mono text-[#a3e635]">
              {proteinPercent}%
            </span>
          </div>
        </div>

        {/* High-visibility Protein Progress Bar */}
        <div className="mt-3 w-full bg-[#1b2231] h-3 rounded-full overflow-hidden p-0.5 border border-[#263145]">
          <div
            className={`h-full rounded-full transition-all duration-700 ease-out ${
              isProteinTargetMet 
                ? 'bg-gradient-to-r from-[#84cc16] via-[#a3e635] to-[#bef264] shadow-[0_0_12px_#a3e635]' 
                : 'bg-gradient-to-r from-[#65a30d] to-[#a3e635]'
            }`}
            style={{ width: `${Math.min(proteinPercent, 100)}%` }}
          />
        </div>

        {/* Context / Motivational Subtitle */}
        <div className="mt-3 flex items-center justify-between text-xs text-gray-400">
          <span className="flex items-center gap-1.5">
            {isProteinTargetMet ? (
              <span className="text-[#a3e635] flex items-center gap-1 font-semibold">
                <Award className="w-3.5 h-3.5" /> Muscle protein synthesis optimized!
              </span>
            ) : (
              <span>Fueling muscle recovery & lean mass retention</span>
            )}
          </span>
          <span className="font-mono text-[11px] text-gray-400">
            {totals.itemCount} items logged
          </span>
        </div>
      </div>

      {/* Secondary Macro Metric Cards */}
      <div className="grid grid-cols-3 gap-2.5">
        {/* Calories Card */}
        <div className="rounded-xl bg-[#121622] border border-[#222a3b] p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wide">Calories</span>
            <Flame className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="mt-2">
            <div className="flex items-baseline gap-1">
              <span className="text-lg font-black font-mono text-white leading-tight">
                {caloriesCurrent}
              </span>
            </div>
            <div className="text-[10px] text-gray-500 font-medium">
              of {caloriesGoal} kcal
            </div>
          </div>
          <div className="mt-2 w-full bg-[#1b2231] h-1.5 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-amber-300 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(caloriesPercent, 100)}%` }}
            />
          </div>
        </div>

        {/* Carbohydrates Card */}
        <div className="rounded-xl bg-[#121622] border border-[#222a3b] p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wide">Carbs</span>
            <Zap className="w-3.5 h-3.5 text-sky-400" />
          </div>
          <div className="mt-2">
            <div className="flex items-baseline gap-1">
              <span className="text-lg font-black font-mono text-white leading-tight">
                {carbsCurrent}g
              </span>
            </div>
            <div className="text-[10px] text-gray-500 font-medium">
              of {carbsGoal}g
            </div>
          </div>
          <div className="mt-2 w-full bg-[#1b2231] h-1.5 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-sky-500 to-cyan-300 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(carbsPercent, 100)}%` }}
            />
          </div>
        </div>

        {/* Fat Card */}
        <div className="rounded-xl bg-[#121622] border border-[#222a3b] p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wide">Fats</span>
            <span className="text-xs text-orange-400 font-bold">💧</span>
          </div>
          <div className="mt-2">
            <div className="flex items-baseline gap-1">
              <span className="text-lg font-black font-mono text-white leading-tight">
                {fatCurrent}g
              </span>
            </div>
            <div className="text-[10px] text-gray-500 font-medium">
              of {fatGoal}g
            </div>
          </div>
          <div className="mt-2 w-full bg-[#1b2231] h-1.5 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-orange-500 to-amber-400 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(fatPercent, 100)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Macro Calorie Distribution Split Bar */}
      <div className="rounded-xl bg-[#10141d] border border-[#1e2636] px-3.5 py-2.5">
        <div className="flex items-center justify-between text-[11px] mb-1.5">
          <span className="text-gray-400 font-medium">Macro Energy Split</span>
          <span className="text-gray-500 font-mono text-[10px]">P : C : F</span>
        </div>
        
        {/* Tri-color Split Bar */}
        <div className="h-2 w-full bg-[#181f2c] rounded-full overflow-hidden flex">
          <div 
            style={{ width: `${proteinRatio}%` }} 
            className="bg-[#a3e635] h-full transition-all duration-500" 
            title={`Protein: ${proteinRatio}%`}
          />
          <div 
            style={{ width: `${carbsRatio}%` }} 
            className="bg-sky-400 h-full transition-all duration-500" 
            title={`Carbs: ${carbsRatio}%`}
          />
          <div 
            style={{ width: `${fatRatio}%` }} 
            className="bg-orange-400 h-full transition-all duration-500" 
            title={`Fat: ${fatRatio}%`}
          />
        </div>

        {/* Legend */}
        <div className="flex items-center justify-between text-[10px] font-mono mt-1.5 text-gray-400">
          <div className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-[#a3e635]" />
            <span>Protein {proteinRatio}%</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-sky-400" />
            <span>Carbs {carbsRatio}%</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-orange-400" />
            <span>Fat {fatRatio}%</span>
          </div>
        </div>
      </div>
    </section>
  );
};
