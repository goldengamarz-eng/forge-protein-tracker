import React, { useState } from 'react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  serverUrl: string;
}

interface Message {
  sender: 'user' | 'bot';
  text: string;
}

export const ProteinChatModal: React.FC<Props> = ({ isOpen, onClose, serverUrl }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'bot',
      text: 'Namaste! Kisi bhi khane ka naam aur quantity likhiye (jaise "100g paneer" ya "4 boiled eggs"), main accurate protein aur macros bata dunga.'
    }
  ]);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSend = async () => {
    if (!query.trim() || loading) return;
    const text = query.trim();
    setQuery('');
    setMessages(prev => [...prev, { sender: 'user', text }]);
    setLoading(true);

    try {
      const res = await fetch(`${serverUrl}/api/food-chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ foodQuery: text })
      });
      const data = await res.json();
      if (data.reply) {
        setMessages(prev => [...prev, { sender: 'bot', text: data.reply }]);
      } else {
        setMessages(prev => [...prev, { sender: 'bot', text: 'Error: Data calculate nahi ho saka. Dobara try karein.' }]);
      }
    } catch {
      setMessages(prev => [...prev, { sender: 'bot', text: 'Server connect nahi ho saka. Internet check karein.' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.75)',
      display: 'flex', flexDirection: 'column', zIndex: 9999, padding: '16px'
    }}>
      <div style={{
        backgroundColor: '#12161f', borderRadius: '18px', border: '1px solid #232b3e',
        display: 'flex', flexDirection: 'column', height: '100%', maxWidth: '480px', margin: 'auto', width: '100%', overflow: 'hidden'
      }}>
        {/* Header */}
        <div style={{
          padding: '16px', borderBottom: '1px solid #1f2738',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#181f2c'
        }}>
          <div>
            <h3 style={{ margin: 0, color: '#39e75f', fontSize: '1.05rem', fontWeight: 700 }}>Forge Protein Bot 💬</h3>
            <span style={{ fontSize: '0.75rem', color: '#8b9bb4' }}>Instant macro & protein check</span>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#cbd5e1', fontSize: '1.3rem', cursor: 'pointer' }}>✕</button>
        </div>

        {/* Chat List */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '16px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {messages.map((m, i) => (
            <div key={i} style={{
              alignSelf: m.sender === 'user' ? 'flex-end' : 'flex-start',
              backgroundColor: m.sender === 'user' ? '#22c55e' : '#1b2230',
              color: m.sender === 'user' ? '#000' : '#f1f5f9',
              padding: '12px 14px', borderRadius: '14px', maxWidth: '85%',
              whiteSpace: 'pre-line', fontSize: '0.9rem', lineHeight: 1.5,
              border: m.sender === 'bot' ? '1px solid #283348' : 'none',
              fontWeight: m.sender === 'user' ? 600 : 400
            }}>
              {m.text}
            </div>
          ))}
          {loading && <div style={{ color: '#39e75f', fontSize: '0.85rem' }}>⏳ Macros calculate ho rahe hain...</div>}
        </div>

        {/* Input Footer */}
        <div style={{ padding: '12px', borderTop: '1px solid #1f2738', display: 'flex', gap: '8px', backgroundColor: '#181f2c' }}>
          <input
            type="text"
            placeholder="Khana likhiye (e.g. 2 roti aur 100g chicken)..."
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSend()}
            style={{
              flex: 1, backgroundColor: '#0e121a', border: '1px solid #2a3449',
              borderRadius: '10px', color: '#fff', padding: '12px', fontSize: '0.9rem', outline: 'none'
            }}
          />
          <button
            onClick={handleSend}
            disabled={loading}
            style={{
              backgroundColor: '#39e75f', color: '#000', border: 'none',
              borderRadius: '10px', padding: '0 18px', fontWeight: 700, cursor: 'pointer'
            }}
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );
};
