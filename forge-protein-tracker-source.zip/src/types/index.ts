export type MealType = 'breakfast' | 'lunch' | 'dinner' | 'snack';

export interface FoodEntry {
  id: string;
  date: string; // YYYY-MM-DD
  mealType: MealType;
  name: string;
  portionSize: string; // e.g. "200g", "1 cup", "2 scoops"
  quantity: number; // default 1
  unit: string; // e.g. "g", "serving", "oz", "item"
  protein: number; // in grams
  calories: number; // in kcal
  carbs: number; // in grams
  fat: number; // in grams
  scannedFromPhoto?: boolean;
  photoThumbnail?: string;
  notes?: string;
  createdAt: string;
}

export type GoalPreset = 'hypertrophy' | 'fat_loss' | 'lean_bulk' | 'maintenance' | 'custom';

export interface DailyGoals {
  protein: number; // default: 160g
  calories: number; // default: 2200 kcal
  carbs: number; // default: 210g
  fat: number; // default: 60g
  bodyWeightKg?: number;
  goalType: GoalPreset;
  updatedAt: string;
}

export interface AIAnalyzedItem {
  id?: string;
  name: string;
  estimatedPortion: string;
  protein: number;
  calories: number;
  carbs: number;
  fat: number;
  confidence?: 'high' | 'medium' | 'low';
  notes?: string;
}

export interface AIPhotoAnalysisResult {
  dishTitle: string;
  summary?: string;
  confidence: 'high' | 'medium' | 'low';
  items: AIAnalyzedItem[];
  totalProtein: number;
  totalCalories: number;
  totalCarbs: number;
  totalFat: number;
  dietaryTags: string[];
  estimationDisclaimer: string;
}

export interface DailyTotals {
  protein: number;
  calories: number;
  carbs: number;
  fat: number;
  itemCount: number;
}

export interface MealTotals {
  protein: number;
  calories: number;
  carbs: number;
  fat: number;
  entries: FoodEntry[];
}
